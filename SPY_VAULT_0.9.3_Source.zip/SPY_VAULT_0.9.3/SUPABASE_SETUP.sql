-- SPY VAULT E2E Cloud Recovery (phase 1)
create table if not exists public.vault_sync (
  user_id uuid primary key references auth.users(id) on delete cascade,
  ciphertext text not null,
  format_version integer not null default 1,
  revision bigint not null default 1,
  device_label text,
  updated_at timestamptz not null default now()
);
alter table public.vault_sync enable row level security;
revoke all on table public.vault_sync from anon;
grant select, insert, update, delete on public.vault_sync to authenticated;
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vault_sync' and policyname='Users can read their own encrypted vault') then
    create policy "Users can read their own encrypted vault" on public.vault_sync for select to authenticated using ((select auth.uid()) = user_id);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vault_sync' and policyname='Users can create their own encrypted vault') then
    create policy "Users can create their own encrypted vault" on public.vault_sync for insert to authenticated with check ((select auth.uid()) = user_id);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vault_sync' and policyname='Users can update their own encrypted vault') then
    create policy "Users can update their own encrypted vault" on public.vault_sync for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='vault_sync' and policyname='Users can delete their own encrypted vault') then
    create policy "Users can delete their own encrypted vault" on public.vault_sync for delete to authenticated using ((select auth.uid()) = user_id);
  end if;
end $$;

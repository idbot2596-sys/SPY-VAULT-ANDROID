# SPY VAULT 0.9.1

Native Android password vault. Package `com.spyvault.app`; minimum SDK 26; target SDK 35.

## 0.9.1 changes
- Fixed Change Master Password dialog sizing: capped to available screen height, scrollable form, pinned Cancel/Update actions, and keyboard resize handling.
- Added optional Password Breach Check using the Have I Been Pwned range API. SHA-1 hashing happens locally; only the first five hash characters are sent. The full password and remaining hash suffix are not transmitted.
- Retained Recently Deleted (30-day recovery) and local Password Health audit.

## Security notes
- Breach checking requires internet and is user-initiated. The service can observe the five-character hash prefix; no password or full hash is uploaded.
- Cloud Sync and Android Autofill are not included in this build.
- Keep an encrypted manual backup before uninstalling/reinstalling. A new signing identity is used in this build.
- Physical-device install, dialog interaction, and live network tests have not been performed.


## 0.9.3 E2E Cloud Recovery (phase 1)
- Added Supabase Auth account creation and email/password sign-in.
- Added explicit encrypted vault upload and restore actions.
- The client uploads only the existing AES-256-GCM encrypted `vault.dat` container (Base64 encoded); master password, derived key and plaintext records are never sent.
- Restore downloads ciphertext and requires the original master password to decrypt locally before replacing the local vault.
- RLS must remain enabled on `public.vault_sync`; the `user_id` column must reference `auth.uid()`.
- This release is manual Sync/Restore. Automatic background sync, conflict resolution/version history and a separate recovery key are not implemented yet.
- Cloud account password is distinct from the vault master password. Email confirmation may be required by Supabase Auth settings.


## 0.9.3 automatic cloud sync
- Once the user links a Supabase account, the refresh token is encrypted using an Android Keystore AES-GCM key.
- Local vault changes mark cloud state dirty and schedule a debounced encrypted upload.
- On vault unlock, the app refreshes the Supabase session and checks the cloud revision; a newer remote vault is authenticated/decrypted locally with the currently unlocked vault key before replacing local data.
- Cloud account password and vault master password remain separate.
- Offline changes remain in the encrypted local vault and are retried on a later save/unlock when connectivity is available.
- Automatic sync requires the user to link a cloud account once from Backup & Sync.
- Multi-device simultaneous-edit conflict resolution and master-password-change recovery still require further testing.

## 0.9.3 automatic cloud sync
- Link a Supabase account once; then vault saves schedule automatic encrypted upload.
- Every local vault unlock refreshes the remembered cloud session and checks whether a newer cloud revision exists.
- Refresh tokens are encrypted at rest using Android Keystore AES-GCM.
- Server receives only the existing AES-256-GCM encrypted vault container; master password and decrypted records are never uploaded.
- If offline, the local encrypted vault remains usable and a later save/unlock retries sync.
- Concurrent remote changes are detected conservatively; automatic upload pauses rather than silently overwriting a newer remote copy.
- Requires one-time account linking from Backup & Sync. Live device/backend testing is still required.

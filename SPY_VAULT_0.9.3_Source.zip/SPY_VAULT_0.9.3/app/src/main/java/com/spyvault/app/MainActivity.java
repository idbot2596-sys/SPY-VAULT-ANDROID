package com.spyvault.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.hardware.biometrics.BiometricPrompt;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.os.CancellationSignal;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.ArrayList;
import javax.crypto.Mac;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    // Reference palette: near-black navy, graphite panels and saturated violet.
    private int BG=0xFF050611;
    private int PANEL=0xFF111528;
    private int PANEL2=0xFF191F35;
    private int BORDER=0xFF30264D;
    private int PURPLE=0xFFB02CFF;
    private int PURPLE2=0xFF7C35FF;
    private int PINK=0xFFDA42FF;
    private int WHITE=0xFFF8F6FF;
    private int SOFT=0xFFC0BDD2;
    private int MUTED=0xFF77788F;
    private int GREEN=0xFF42D69A;
    private int RED=0xFFFF557C;
    private String themeMode="Dark";
    private String accentMode="Purple";
    private String fontMode="Medium";
    private static final int ITERATIONS=600000, KEY_BITS=256, SALT_LEN=16, NONCE_LEN=12;
    private static final String FILE="vault.dat";
    private static final String BIO_FILE="vault.bio";
    private static final String BIO_ALIAS="SPY_VAULT_BIOMETRIC_V1";
    // Supabase project uses RLS; only encrypted vault container is uploaded.
    private static final String CLOUD_URL="https://erfmnjyokqhhilrwijpt.supabase.co";
    private static final String CLOUD_ANON="sb_publishable_f6g78p3aa6mjQyrgkpB1wg_20GsiYV9";
    private static final int REQ_EXPORT=4101, REQ_IMPORT=4102;
    private static final String[] CATEGORIES={"Login","Social Media","Banking","Cards","Work","Shopping","Gaming","Notes","Other"};
    private final SecureRandom random=new SecureRandom();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final java.util.concurrent.atomic.AtomicBoolean cloudSyncRunning=new java.util.concurrent.atomic.AtomicBoolean(false);
    private LinearLayout shell, page, recordsHost;
    private JSONArray records=new JSONArray();
    private byte[] activeKey;
    private boolean isUnlocked=false, backgroundLocked=false, introInProgress=false;
    private long backgroundAt=0;
    private String searchQuery="", selectedCategory="All";
    private int introPage=0;
    private boolean lastFromVault=false;
    private int autoLockMinutes=5;
    private EditText dashboardSearch;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        themeMode=getPreferences(0).getString("theme","Dark");
        accentMode=getPreferences(0).getString("accent","Purple");
        fontMode=getPreferences(0).getString("font_size","Medium");
        applyPalette();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        autoLockMinutes=getPreferences(0).getInt("autolock",5);
        if (hasVault()) showGate();
        else if (!getPreferences(0).getBoolean("intro_seen",false)) showSplash();
        else showGate();
    }

    @Override protected void onPause() {
        super.onPause();
        if (isUnlocked) backgroundAt=System.currentTimeMillis();
    }
    @Override protected void onResume() {
        super.onResume();
        if (isUnlocked && backgroundAt>0 &&
            System.currentTimeMillis()-backgroundAt >= autoLockMinutes*60_000L) {
            lockVault(); showGate();
        }
        backgroundAt=0;
    }
    @Override public void onBackPressed() {
        if (!isUnlocked) { super.onBackPressed(); return; }
        showHome();
    }

    private void applyPalette(){
        boolean light="Light".equals(themeMode) || ("System".equals(themeMode) &&
            (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)==android.content.res.Configuration.UI_MODE_NIGHT_NO);
        if(light){
            BG=0xFFF5F3FB;PANEL=0xFFFFFFFF;PANEL2=0xFFECE8F7;BORDER=0xFFD9CDEB;
            PURPLE=0xFF8B26D9;PURPLE2=0xFF6925C7;PINK=0xFFB52EE8;
            WHITE=0xFF1B1730;SOFT=0xFF57516B;MUTED=0xFF817A95;GREEN=0xFF16845D;RED=0xFFC52B55;
        }else{
            BG=0xFF050611;PANEL=0xFF111528;PANEL2=0xFF191F35;BORDER=0xFF30264D;
            PURPLE=0xFFB02CFF;PURPLE2=0xFF7C35FF;PINK=0xFFDA42FF;
            WHITE=0xFFF8F6FF;SOFT=0xFFC0BDD2;MUTED=0xFF77788F;GREEN=0xFF42D69A;RED=0xFFFF557C;
        }
        if("Blue".equals(accentMode)){PURPLE=0xFF3994FF;PURPLE2=0xFF2563EB;PINK=0xFF22D3EE;}
        else if("Orange".equals(accentMode)){PURPLE=0xFFFF9A35;PURPLE2=0xFFEA580C;PINK=0xFFFBBF24;}
        else if("Cyan".equals(accentMode)){PURPLE=0xFF22D3EE;PURPLE2=0xFF0891B2;PINK=0xFF67E8F9;}
        else if("Red".equals(accentMode)){PURPLE=0xFFF05272;PURPLE2=0xFFBE123C;PINK=0xFFFB7185;}
        if(getWindow()!=null){getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);}
    }
    private void setThemeMode(String mode){
        themeMode=mode;getPreferences(0).edit().putString("theme",mode).apply();applyPalette();showAppearance();
    }
    private void setAccentMode(String mode){
        accentMode=mode;getPreferences(0).edit().putString("accent",mode).apply();applyPalette();showAppearance();
    }
    private void setFontMode(String mode){
        fontMode=mode;getPreferences(0).edit().putString("font_size",mode).apply();showAppearance();
    }

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable solid(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private GradientDrawable gradient(int radius) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{PURPLE2,PURPLE,PINK});
        d.setCornerRadius(dp(radius)); return d;
    }
    private TextView txt(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(value);
        float scale="Small".equals(fontMode)?0.92f:("Large".equals(fontMode)?1.10f:1.0f);
        t.setTextSize(size*scale); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setIncludeFontPadding(true); return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void padding(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private void gap(LinearLayout into,int height){View v=new View(this);into.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void margin(View v,int top,int bottom){
        LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)v.getLayoutParams();p.topMargin=dp(top);p.bottomMargin=dp(bottom);v.setLayoutParams(p);
    }
    private String upper(String s){return s==null?"":s.toUpperCase(Locale.US);}

    // Outer frame keeps bottom navigation fixed while page content scrolls.
    // Android 15 / targetSdk 35 enforces edge-to-edge. Keep app content below
    // the status bar and above the gesture/navigation area on every screen.
    private void applySystemBarInsets(View root){
        if(root==null)return;
        root.setOnApplyWindowInsetsListener((view,insets)->{
            int top=0,bottom=0;
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(
                    android.view.WindowInsets.Type.statusBars() |
                    android.view.WindowInsets.Type.navigationBars());
                top=bars.top;bottom=bars.bottom;
            }else{
                top=insets.getSystemWindowInsetTop();
                bottom=insets.getSystemWindowInsetBottom();
            }
            view.setPadding(view.getPaddingLeft(),top,view.getPaddingRight(),bottom);
            return insets;
        });
        root.setFitsSystemWindows(false);
        root.requestApplyInsets();
    }

    private void initAuth(){
        shell=col();shell.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        page=col();padding(page,22,20,22,24);sc.addView(page);
        shell.addView(sc,new LinearLayout.LayoutParams(-1,-1));applySystemBarInsets(shell);setContentView(shell);
    }
    private void authBrand(int size){
        LinearLayout b=col();b.setGravity(Gravity.CENTER);
        ImageView logo=new ImageView(this);int id=getResources().getIdentifier("spy_vault_shield","drawable",getPackageName());
        if(id!=0)logo.setImageResource(id);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        b.addView(logo,new LinearLayout.LayoutParams(dp(size),dp(size)));
        TextView name=txt("SPY VAULT",19,WHITE,true);name.setTypeface(Typeface.create("sans-serif",Typeface.BOLD_ITALIC));name.setGravity(Gravity.CENTER);b.addView(name);
        TextView sub=txt("YOUR PRIVATE PASSWORD VAULT",8,SOFT,true);sub.setLetterSpacing(.18f);sub.setGravity(Gravity.CENTER);b.addView(sub);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(13);page.addView(b,p);
    }
    private void addAuthHero(int height){
        FrameLayout stage=new FrameLayout(this);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFF21103D,0xFF0D1020,0xFF160A2C});
        bg.setCornerRadius(dp(24));bg.setStroke(dp(1),0xFF59318A);stage.setBackground(bg);stage.setClipToOutline(true);
        stage.setElevation(dp(8));
        ImageView art=new ImageView(this);
        int id=getResources().getIdentifier("auth_shield_3d","drawable",getPackageName());
        if(id!=0)art.setImageResource(id);
        art.setScaleType(ImageView.ScaleType.FIT_CENTER);art.setAdjustViewBounds(true);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,-1);ap.setMargins(dp(8),dp(4),dp(8),dp(4));
        stage.addView(art,ap);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(height));
        p.bottomMargin=dp(17);p.topMargin=dp(2);page.addView(stage,p);
    }
    private void initInner(String title,String subtitle,Runnable back){
        shell=col();shell.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        page=col();padding(page,18,12,18,22);sc.addView(page);
        shell.addView(sc,new LinearLayout.LayoutParams(-1,-1));applySystemBarInsets(shell);setContentView(shell);
        LinearLayout top=row();
        TextView arrow=txt("‹",32,SOFT,false);arrow.setGravity(Gravity.CENTER);
        top.addView(arrow,new LinearLayout.LayoutParams(dp(42),dp(48)));
        LinearLayout titleBox=col();titleBox.setGravity(Gravity.CENTER);
        titleBox.addView(txt(title,16,WHITE,true));
        TextView sub=txt(upper(subtitle),8,MUTED,true);sub.setLetterSpacing(.10f);titleBox.addView(sub);
        top.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        TextView spacer=txt(" ",20,MUTED,false);top.addView(spacer,new LinearLayout.LayoutParams(dp(42),dp(48)));
        page.addView(top);
        View line=new View(this);line.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(5);lp.bottomMargin=dp(14);page.addView(line,lp);
        arrow.setOnClickListener(v->back.run());
    }

    private void init(String title,String subtitle) { init(title,subtitle,-1); }

    private void init(String title,String subtitle,int activeTab) {
        shell=col(); shell.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(this); sc.setFillViewport(true);
        page=col(); padding(page,18,16,18,22); sc.addView(page);
        shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        applySystemBarInsets(shell);
        setContentView(shell);
        addBrandHeader(subtitle);
        if(title!=null){
            TextView h=txt(title,25,WHITE,true);
            LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);
            hp.topMargin=dp(22);hp.bottomMargin=dp(13);page.addView(h,hp);
        }
        if(activeTab>=0) addBottomNav(activeTab);
    }

    private void addBrandHeader(String subtitle) {
        LinearLayout r=row();
        ImageView logo=new ImageView(this);
        int id=getResources().getIdentifier("spy_vault_shield","drawable",getPackageName());
        if(id!=0)logo.setImageResource(id);
        else logo.setImageResource(com.spyvault.app.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setBackground(solid(0xFF201238,14,BORDER));logo.setClipToOutline(true);
        r.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout names=col();padding(names,10,0,0,0);
        TextView brand=txt("SPY VAULT",20,WHITE,true);brand.setTypeface(Typeface.create("sans-serif",Typeface.BOLD_ITALIC));
        names.addView(brand);
        TextView sub=txt(upper(subtitle),8,MUTED,true);sub.setLetterSpacing(.16f);names.addView(sub);
        r.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView status=txt("●  SECURE",9,GREEN,true);
        status.setBackground(solid(0xFF102D2A,24,0));padding(status,10,7,10,7);r.addView(status);
        TextView more=txt("⋮",21,SOFT,true);more.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(28),dp(42));mp.leftMargin=dp(5);r.addView(more,mp);
        more.setOnClickListener(v->{if(isUnlocked)showDrawer();});
        page.addView(r);
    }

    private void addBottomNav(int selected) {
        LinearLayout nav=row();nav.setGravity(Gravity.CENTER);
        nav.setBackground(solid(0xFF101426,22,BORDER));padding(nav,6,7,6,7);
        String[] labels={"Home","Vault","Generator","Settings"};
        String[] icons={"⌂","▣","⚙","☷"};
        for(int i=0;i<labels.length;i++){
            final int ix=i;
            LinearLayout item=col();item.setGravity(Gravity.CENTER);
            if(i==selected)item.setBackground(solid(0xFF30204B,16,0));
            TextView ic=txt(icons[i],20,i==selected?PINK:MUTED,true);ic.setGravity(Gravity.CENTER);item.addView(ic);
            TextView tx=txt(labels[i],9,i==selected?WHITE:MUTED,true);tx.setGravity(Gravity.CENTER);item.addView(tx);
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));
            item.setOnClickListener(v->{
                if(!isUnlocked){showGate();return;}
                if(ix==0)showHome();else if(ix==1)showVault();else if(ix==2)showGenerator();else showSettings();
            });
        }
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.leftMargin=dp(12);np.rightMargin=dp(12);np.bottomMargin=dp(8);np.topMargin=dp(5);
        shell.addView(nav,np);
    }

    private void fieldLabel(String title) {
        TextView t=txt(upper(title),9,SOFT,true);t.setLetterSpacing(.09f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.leftMargin=dp(3);p.topMargin=dp(6);p.bottomMargin=dp(6);page.addView(t,p);
    }

    private EditText edit(String hint,boolean secret) {
        EditText e=new EditText(this); e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setHint(hint);e.setTextSize("Large".equals(fontMode)?16:14);e.setBackground(solid(PANEL2,15,BORDER));padding(e,15,10,15,10);
        if(Build.VERSION.SDK_INT>=29)e.setTextCursorDrawable(null);
        if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.bottomMargin=dp(10);page.addView(e,p);
        return e;
    }
    private EditText secretEdit(String hint) {
        LinearLayout r=row();r.setBackground(solid(PANEL2,14,BORDER));padding(r,10,0,10,0);
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setHint(hint);e.setTextSize(14);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setBackgroundColor(Color.TRANSPARENT);r.addView(e,new LinearLayout.LayoutParams(0,dp(49),1));
        TextView eye=txt("◉",16,PURPLE,true);eye.setGravity(Gravity.CENTER);r.addView(eye,new LinearLayout.LayoutParams(dp(34),dp(45)));
        final boolean[] visible={false};
        eye.setOnClickListener(v->{visible[0]=!visible[0];e.setInputType(InputType.TYPE_CLASS_TEXT|
            (visible[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));e.setSelection(e.length());});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);page.addView(r,p);
        return e;
    }

    private void button(String text,Runnable action) {
        TextView b=txt(text,13,Color.WHITE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(gradient(26));b.setElevation(dp(7));padding(b,15,14,15,14);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.bottomMargin=dp(10);page.addView(b,p);
        b.setOnClickListener(v->action.run());
    }
    private void ghostButton(String text,Runnable action) {
        TextView b=txt(text,12,PURPLE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(solid(PANEL,25,BORDER));b.setElevation(dp(3));padding(b,12,13,12,13);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(46));p.bottomMargin=dp(9);page.addView(b,p);
        b.setOnClickListener(v->action.run());
    }
    private void card(String title,String detail,String trailing,Runnable click) {
        LinearLayout c=col();c.setBackground(solid(PANEL,17,BORDER));c.setElevation(dp(5));padding(c,14,13,14,13);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(9);page.addView(c,cp);
        LinearLayout r=row();r.addView(txt(title,13,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        if(trailing!=null)r.addView(txt(trailing,9,PURPLE,true));c.addView(r);
        if(detail!=null){TextView d=txt(detail,11,SOFT,false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(5);c.addView(d,p);}
        if(click!=null)c.setOnClickListener(v->click.run());
    }
    private void hero(String title,String detail) {
        LinearLayout box=col();box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackground(solid(0xFF0C1020,21,BORDER));box.setElevation(dp(8));padding(box,17,17,17,17);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.bottomMargin=dp(17);page.addView(box,bp);
        ImageView img=new ImageView(this);
        int id=getResources().getIdentifier("spy_vault_mark","drawable",getPackageName());
        if(id!=0)img.setImageResource(id);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);img.setBackground(solid(0xFF1B1230,20,0));img.setClipToOutline(true);
        box.addView(img,new LinearLayout.LayoutParams(dp(84),dp(84)));
        TextView h=txt(title,18,WHITE,true);h.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(11);box.addView(h,hp);
        TextView d=txt(detail,11,SOFT,false);d.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(-1,-2);dpv.topMargin=dp(6);box.addView(d,dpv);
    }

    private TextView chip(String title,boolean active,Runnable action) {
        TextView t=txt(title,10,active?WHITE:SOFT,true);t.setGravity(Gravity.CENTER);
        t.setBackground(active?gradient(22):solid(PANEL,22,BORDER));padding(t,13,9,13,9);
        t.setOnClickListener(v->action.run());return t;
    }

    private void showSplash() {
        initAuth();
        LinearLayout center=col();center.setGravity(Gravity.CENTER);padding(center,14,34,14,22);
        ImageView scene=new ImageView(this);
        int sceneId=getResources().getIdentifier("onboard_safe","drawable",getPackageName());
        if(sceneId!=0)scene.setImageResource(sceneId);
        scene.setScaleType(ImageView.ScaleType.CENTER_CROP);
        scene.setBackground(solid(0xFF10091E,28,BORDER));scene.setClipToOutline(true);
        LinearLayout.LayoutParams sceneLp=new LinearLayout.LayoutParams(-1,dp(260));
        sceneLp.bottomMargin=dp(12);center.addView(scene,sceneLp);
        ImageView brand=new ImageView(this);
        int logoId=getResources().getIdentifier("spy_vault_mark","drawable",getPackageName());
        if(logoId!=0)brand.setImageResource(logoId);
        brand.setScaleType(ImageView.ScaleType.FIT_CENTER);
        center.addView(brand,new LinearLayout.LayoutParams(dp(224),dp(224)));
        ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);pb.setProgressTintList(ColorStateList.valueOf(PURPLE));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(130),dp(4));pp.topMargin=dp(15);center.addView(pb,pp);
        page.addView(center,new LinearLayout.LayoutParams(-1,-1));
        handler.postDelayed(()->{if(!hasVault())showIntro(0);else showGate();},1100);
    }

    private void showIntro(int index) {
        introInProgress=true;introPage=index;
        initAuth();authBrand(46);
        TextView step=txt("0"+(index+1)+"  /  03",10,PURPLE,true);step.setGravity(Gravity.RIGHT);page.addView(step);
        FrameLayout stage=new FrameLayout(this);
        stage.setBackground(solid(0xFF0C0A1A,24,BORDER));stage.setClipToOutline(true);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(286));ip.topMargin=dp(10);ip.bottomMargin=dp(18);page.addView(stage,ip);
        ImageView logo=new ImageView(this);
        String[] illustrations={"onboard_safe","onboard_lock","onboard_cloud"};
        int id=getResources().getIdentifier(illustrations[index],"drawable",getPackageName());
        if(id==0)id=getResources().getIdentifier("spy_vault_mark","drawable",getPackageName());
        if(id!=0)logo.setImageResource(id);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        stage.addView(logo,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x00050611,0x33050611,0x99050611}));
        stage.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        String[] headings={"Keep Your Passwords Safe","Stronger Security","Your Data Your Control"};
        String[] bodies={
            "Secure, private and organized password management for your digital life.",
            "Encrypted storage and optional biometric unlock help protect your accounts.",
            "Keep an encrypted backup under your control. Cloud sync will be added separately."
        };
        TextView h=txt(headings[index],22,WHITE,true);h.setGravity(Gravity.CENTER);
        page.addView(h);
        TextView d=txt(bodies[index],12,SOFT,false);d.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(-1,-2);dpv.topMargin=dp(9);dpv.bottomMargin=dp(18);page.addView(d,dpv);
        LinearLayout dots=row();dots.setGravity(Gravity.CENTER);
        for(int i=0;i<3;i++){TextView dot=txt(i==index?"●":"○",13,i==index?PINK:MUTED,true);padding(dot,7,4,7,4);dots.addView(dot);}
        page.addView(dots);
        button(index==2?"GET STARTED":"NEXT  →",()->{
            if(index<2)showIntro(index+1);
            else {getPreferences(0).edit().putBoolean("intro_seen",true).apply();introInProgress=false;showGate();}
        });
        ghostButton("SKIP INTRO",()->{
            getPreferences(0).edit().putBoolean("intro_seen",true).apply();introInProgress=false;showGate();
        });
    }

    private void showGate() {
        isUnlocked=false;activeKey=null;
        if(!hasVault()) {
            initAuth();authBrand(48);addAuthHero(158);
            TextView heading=txt("Create Master Password",23,WHITE,true);heading.setGravity(Gravity.CENTER);
            page.addView(heading);
            TextView desc=txt("One strong password protects everything in your vault.",12,SOFT,false);desc.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(5);d.bottomMargin=dp(15);page.addView(desc,d);
            fieldLabel("Master password");
            EditText a=secretEdit("Enter master password");
            fieldLabel("Confirm master password");
            EditText b=secretEdit("Confirm master password");
            TextView strength=txt("Password strength  ·  use 12+ characters",10,MUTED,true);page.addView(strength);
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
            bar.setMax(4);bar.setProgressTintList(ColorStateList.valueOf(PURPLE));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(5));bp.topMargin=dp(5);bp.bottomMargin=dp(3);page.addView(bar,bp);
            a.addTextChangedListener(new TextWatcher(){
                public void beforeTextChanged(CharSequence s,int st,int c,int a){}
                public void onTextChanged(CharSequence s,int st,int before,int count){
                    int v=0;String x=s.toString();if(x.length()>=8)v++;if(x.length()>=12)v++;if(x.matches(".*[A-Z].*")&&x.matches(".*[a-z].*"))v++;if(x.matches(".*[0-9].*")&&x.matches(".*[^A-Za-z0-9].*"))v++;
                    bar.setProgress(v);strength.setText(v>=4?"Password strength  ·  Strong":(v>=2?"Password strength  ·  Getting stronger":"Password strength  ·  Add length and variety"));
                }
                public void afterTextChanged(Editable e){}
            });
            LinearLayout hints=col();padding(hints,4,9,4,12);
            addHint(hints,"✓  At least 12 characters");addHint(hints,"✓  Mix letters and numbers");addHint(hints,"✓  Special characters recommended");
            page.addView(hints);
            button("CREATE VAULT",()->{
                String x=a.getText().toString(),y=b.getText().toString();
                if(x.length()<12){toast("Use at least 12 characters.");return;}
                if(!x.equals(y)){toast("Passwords do not match.");return;}
                try{byte[] salt=randomBytes(SALT_LEN);activeKey=derive(x.toCharArray(),salt);records=new JSONArray();saveVault(salt,activeKey,records);isUnlocked=true;showHome();startAutomaticCloudSync();}
                catch(Exception ex){toast("Vault creation failed.");}
            });
            ghostButton("RESTORE EXISTING CLOUD VAULT",()->showCloudRecovery());
            LinearLayout privacy=col();privacy.setBackground(solid(PANEL,18,BORDER));padding(privacy,15,13,15,13);
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=dp(3);page.addView(privacy,pp);
            LinearLayout pr=row();pr.addView(txt("PRIVATE BY DESIGN",12,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));pr.addView(txt("AES-256-GCM",9,PURPLE,true));privacy.addView(pr);
            TextView detail=txt("Your master password never leaves this device. Your vault is encrypted locally.",11,SOFT,false);LinearLayout.LayoutParams det=new LinearLayout.LayoutParams(-1,-2);det.topMargin=dp(7);privacy.addView(detail,det);
        } else {
            initAuth();authBrand(46);addAuthHero(224);
            TextView h=txt("Unlock Your Vault",24,WHITE,true);h.setGravity(Gravity.CENTER);
            page.addView(h);
            TextView d=txt("Your passwords are encrypted. Unlock to access your private vault.",12,SOFT,false);d.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(-1,-2);dpv.topMargin=dp(6);dpv.bottomMargin=dp(17);page.addView(d,dpv);
            fieldLabel("MASTER PASSWORD");
            EditText pass=secretEdit("Enter master password");
            button("UNLOCK MY VAULT",()->{
                try{VaultData data=readVault(pass.getText().toString().toCharArray());activeKey=data.key;records=data.records;isUnlocked=true;showHome();startAutomaticCloudSync();}
                catch(Exception ex){toast("Incorrect master password or damaged vault.");}
            });
            TextView or=txt("──────────────  OR  ──────────────",10,MUTED,true);or.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2);op.topMargin=dp(4);op.bottomMargin=dp(11);page.addView(or,op);
            if(hasBiometricKey())button("◎   UNLOCK WITH BIOMETRICS",()->beginBiometricUnlock());
            else ghostButton("◎   SET UP FINGERPRINT",()->toast("Unlock with your master password, then enable fingerprint unlock in Security Center."));
            LinearLayout secure=col();secure.setBackground(solid(PANEL,18,BORDER));padding(secure,15,13,15,13);
            LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(9);page.addView(secure,sp);
            LinearLayout sr=row();sr.addView(txt("YOUR VAULT IS ENCRYPTED",11,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));sr.addView(txt("PROTECTED",9,PURPLE,true));secure.addView(sr);
            TextView note=txt("Master password decrypts your saved logins. Biometric unlock is an optional convenience.",11,SOFT,false);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(6);secure.addView(note,np);
        }
    }

    private View labelledLogo(int size) {
        ImageView im=new ImageView(this);
        int id=getResources().getIdentifier("spy_vault_shield","drawable",getPackageName());
        if(id!=0)im.setImageResource(id);else im.setImageResource(com.spyvault.app.R.mipmap.ic_launcher);
        im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout holder=col();holder.setGravity(Gravity.CENTER);
        holder.addView(im,new LinearLayout.LayoutParams(dp(size),dp(size)));
        return holder;
    }
    private void addHint(LinearLayout parent,String text){
        TextView t=txt(text,10,GREEN,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(4);parent.addView(t,p);
    }

    private void premiumDashboardHero(){
        FrameLayout frame=new FrameLayout(this);
        frame.setBackground(solid(0xFF0B0A18,22,BORDER));frame.setClipToOutline(true);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(176));
        fp.bottomMargin=dp(14);page.addView(frame,fp);
        ImageView art=new ImageView(this);
        int id=getResources().getIdentifier("onboard_safe","drawable",getPackageName());
        if(id!=0)art.setImageResource(id);art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(art,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);
        GradientDrawable overlay=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xEE080713,0x88080713,0x11080713});
        shade.setBackground(overlay);frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout copy=col();copy.setGravity(Gravity.CENTER_VERTICAL);padding(copy,17,8,8,8);
        TextView eyebrow=txt("SPY VAULT  /  PRIVATE STORAGE",8,0xFFE0B8FF,true);eyebrow.setLetterSpacing(.13f);copy.addView(eyebrow);
        TextView heading=txt("Your digital life.\nUnder lock.",19,WHITE,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(190),-2);hp.topMargin=dp(7);copy.addView(heading,hp);
        TextView status=txt("AES-256 ENCRYPTED  •  LOCAL FIRST",7,0xFFD5C9E8,true);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2);sp.topMargin=dp(8);copy.addView(status,sp);
        frame.addView(copy,new FrameLayout.LayoutParams(-1,-1,Gravity.LEFT|Gravity.CENTER_VERTICAL));
        frame.setElevation(dp(8));
    }

    private void showHome() {
        if(!isUnlocked){showGate();return;}
        lastFromVault=false;
        init("Welcome Back!","Your vault is secured",0);
        TextView protectedText=txt("●  Your vault is secured",10,GREEN,true);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.bottomMargin=dp(12);page.addView(protectedText,pp);
        premiumDashboardHero();
        EditText search=edit("Search passwords...",false);
        dashboardSearch=search;
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int start,int before,int count){searchQuery=s.toString().toLowerCase(Locale.US);fillRecent();}
            public void afterTextChanged(Editable e){}
        });
        LinearLayout stats=gridRow();
        stats.addView(statTile("▣",String.valueOf(activeCount()),"Total Items",PURPLE),new LinearLayout.LayoutParams(0,dp(94),1));
        int logins=countCategory("Login");
        stats.addView(statTile("▣",String.valueOf(logins),"Logins",0xFF32D98A),new LinearLayout.LayoutParams(0,dp(94),1));
        LinearLayout stats2=gridRow();
        stats2.addView(statTile("▤",String.valueOf(countNotes()),"Notes",0xFFFF4F8B),new LinearLayout.LayoutParams(0,dp(94),1));
        stats2.addView(statTile("▣",String.valueOf(countCategory("Cards")),"Cards",0xFFB54BFF),new LinearLayout.LayoutParams(0,dp(94),1));
        TextView heading=txt("Recent Items",14,WHITE,true);
        LinearLayout hr=row();hr.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        TextView see=txt("See All",10,PURPLE,true);hr.addView(see);see.setOnClickListener(v->showVault());
        LinearLayout.LayoutParams hparams=new LinearLayout.LayoutParams(-1,-2);hparams.topMargin=dp(19);hparams.bottomMargin=dp(8);page.addView(hr,hparams);
        recordsHost=col();page.addView(recordsHost);
        fillRecent();
    }

    private LinearLayout gridRow(){LinearLayout r=row();LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);page.addView(r,p);return r;}
    private View statTile(String icon,String count,String caption,int accent) {
        LinearLayout c=col();c.setBackground(solid(PANEL,15,BORDER));c.setElevation(dp(6));padding(c,12,10,12,10);
        LinearLayout r=row();
        TextView ic=txt(icon,17,accent,true);r.addView(ic);
        TextView n=txt(count,20,WHITE,true);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);np.leftMargin=dp(9);r.addView(n,np);
        c.addView(r);TextView cap=txt(caption,9,MUTED,true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(3);c.addView(cap,cp);
        return c;
    }
    private boolean isDeleted(JSONObject o){ return o!=null && o.optLong("deletedAt",0L)>0L; }
    private int deletedCount(){ int n=0; for(int i=0;i<records.length();i++) if(isDeleted(records.optJSONObject(i))) n++; return n; }
    private int activeCount(){ int n=0; for(int i=0;i<records.length();i++) if(records.optJSONObject(i)!=null&&!isDeleted(records.optJSONObject(i))) n++; return n; }
    private int countCategory(String category){
        int n=0;for(int i=0;i<records.length();i++){JSONObject o=records.optJSONObject(i);if(o!=null&&!isDeleted(o)&&category.equalsIgnoreCase(o.optString("category","Login")))n++;}return n;
    }
    private int countNotes(){
        int n=0;for(int i=0;i<records.length();i++){JSONObject o=records.optJSONObject(i);if(o!=null&&!isDeleted(o)&&!o.optString("notes").isEmpty())n++;}return n;
    }
    private void fillRecent(){
        if(recordsHost==null)return;recordsHost.removeAllViews();int count=0;
        for(int i=records.length()-1;i>=0;i--){
            JSONObject o=records.optJSONObject(i);if(o==null||isDeleted(o))continue;
            String site=o.optString("site"),user=o.optString("username");
            if(!(site+" "+user+" "+o.optString("category")).toLowerCase(Locale.US).contains(searchQuery))continue;
            addRecordRow(recordsHost,i,o);if(++count>=5)break;
        }
        if(count==0){
            LinearLayout emptyCard=col();emptyCard.setGravity(Gravity.CENTER);emptyCard.setBackground(solid(PANEL,18,BORDER));padding(emptyCard,18,18,18,18);
            TextView emptyIcon=txt(activeCount()==0?"🔐":"⌕",30,PURPLE,true);emptyIcon.setGravity(Gravity.CENTER);
            emptyCard.addView(emptyIcon,new LinearLayout.LayoutParams(-1,dp(48)));
            TextView emptyTitle=txt(activeCount()==0?"Your vault is ready":"No results found",14,WHITE,true);emptyTitle.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams etp=new LinearLayout.LayoutParams(-1,-2);etp.topMargin=dp(7);emptyCard.addView(emptyTitle,etp);
            TextView empty=txt(activeCount()==0?"Add your first login to keep it protected and easy to find.":"Try another search or clear your filters.",10,MUTED,false);empty.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.topMargin=dp(5);ep.bottomMargin=dp(12);emptyCard.addView(empty,ep);
            if(activeCount()==0){TextView addFirst=txt("＋  ADD YOUR FIRST PASSWORD",10,WHITE,true);addFirst.setGravity(Gravity.CENTER);addFirst.setBackground(gradient(22));padding(addFirst,12,12,12,12);emptyCard.addView(addFirst);addFirst.setOnClickListener(v->showEditor(-1));}
            LinearLayout.LayoutParams ecp=new LinearLayout.LayoutParams(-1,-2);ecp.topMargin=dp(8);recordsHost.addView(emptyCard,ecp);
        }

    }

    private void showVault() {
        lastFromVault=true;
        init("Vault","All saved passwords",1);
        EditText search=edit("Search passwords...",false);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){searchQuery=s.toString().toLowerCase(Locale.US);fillVaultList();}
            public void afterTextChanged(Editable e){}
        });
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=row();
        String[] groups={"All","Login","Social Media","Banking","Cards","Work","Shopping","Gaming","Notes"};
        for(String g:groups){
            final String cat=g;
            TextView c=chip(g,g.equals(selectedCategory),()->{selectedCategory=cat;showVault();});
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);cp.rightMargin=dp(7);chips.addView(c,cp);
        }
        hsv.addView(chips);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(14);page.addView(hsv,hp);
        TextView add=txt("＋  ADD PASSWORD",11,WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(gradient(24));padding(add,12,13,12,13);
        LinearLayout.LayoutParams addp=new LinearLayout.LayoutParams(-1,dp(46));addp.bottomMargin=dp(14);page.addView(add,addp);
        add.setOnClickListener(v->showEditor(-1));
        recordsHost=col();page.addView(recordsHost);fillVaultList();
    }

    private void fillVaultList(){
        if(recordsHost==null)return;recordsHost.removeAllViews();int count=0;
        for(int i=records.length()-1;i>=0;i--){
            JSONObject o=records.optJSONObject(i);if(o==null||isDeleted(o))continue;
            String cat=o.optString("category","Login"),site=o.optString("site"),user=o.optString("username");
            if(!"All".equals(selectedCategory)&&!selectedCategory.equalsIgnoreCase(cat))continue;
            if(!(site+" "+user+" "+cat).toLowerCase(Locale.US).contains(searchQuery))continue;
            addRecordRow(recordsHost,i,o);count++;
        }
        if(count==0)recordsHost.addView(txt("No saved items in this category.",11,MUTED,false));
    }

    private void addRecordRow(LinearLayout parent,int index,JSONObject o){
        String site=o.optString("site","Untitled");String user=o.optString("username");String cat=o.optString("category","Login");
        LinearLayout row=row();row.setBackground(solid(PANEL,15,BORDER));row.setElevation(dp(3));padding(row,11,10,11,10);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(7);parent.addView(row,rp);
        TextView icon=txt(o.optString("icon",site.isEmpty()?"•":site.substring(0,1).toUpperCase(Locale.US)),15,WHITE,true);
        icon.setGravity(Gravity.CENTER);icon.setBackground(solid(categoryColor(cat),12,0));
        row.addView(icon,new LinearLayout.LayoutParams(dp(39),dp(39)));
        LinearLayout details=col();padding(details,11,0,0,0);
        details.addView(txt(site,12,WHITE,true));
        details.addView(txt(user.isEmpty()?cat:user,9,MUTED,false));
        row.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=txt(o.optBoolean("favorite",false)?"★":"☆",19,o.optBoolean("favorite",false)?0xFFFFC857:MUTED,true);row.addView(fav);
        fav.setOnClickListener(v->{try{boolean next=!o.optBoolean("favorite",false);o.put("favorite",next);persist();fav.setText(next?"★":"☆");}catch(Exception e){toast("Could not update favorite.");}});
        TextView arrow=txt("›",23,MUTED,true);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-2,-2);ap.leftMargin=dp(7);row.addView(arrow,ap);
        row.setOnClickListener(v->showDetails(index));
    }
    private int categoryColor(String c){
        if("Banking".equalsIgnoreCase(c))return 0xFFB57B25;
        if("Social Media".equalsIgnoreCase(c))return 0xFF753BBA;
        if("Gaming".equalsIgnoreCase(c))return 0xFF247FCA;
        if("Work".equalsIgnoreCase(c))return 0xFF1C927F;
        if("Shopping".equalsIgnoreCase(c))return 0xFFB6536C;
        return 0xFF5935A4;
    }

    private void showEditor(int index) {
        JSONObject old=index>=0?records.optJSONObject(index):null;
        initInner(index<0?"Add Password":"Edit Password","Save login",()->{if(lastFromVault)showVault();else showHome();});
        LinearLayout appIcon=col();appIcon.setGravity(Gravity.CENTER);
        String[] iconChoices={"G","IG","D","f","N","✈","🌐","★"};
        String[] iconNames={"Google","Instagram","Discord","Facebook","Netflix","Telegram","Website","Other"};
        String[] iconValue={ "G","IG","D","f","N","✈","🌐","★" };
        String savedIcon=old==null?"🌐":old.optString("icon","🌐");
        final String[] chosenIcon={savedIcon};
        FrameLayout iconFrame=new FrameLayout(this);
        iconFrame.setBackground(solid(PANEL2,20,BORDER));
        ImageView image=new ImageView(this);
        int markId=getResources().getIdentifier("spy_vault_shield","drawable",getPackageName());
        if(markId!=0)image.setImageResource(markId);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iconFrame.addView(image,new FrameLayout.LayoutParams(-1,-1));
        TextView iconBadge=txt(chosenIcon[0],11,WHITE,true);
        iconBadge.setGravity(Gravity.CENTER);iconBadge.setBackground(solid(PURPLE2,10,0));
        FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(dp(25),dp(25),Gravity.BOTTOM|Gravity.RIGHT);
        iconFrame.addView(iconBadge,badgeLp);
        LinearLayout.LayoutParams imageLp=new LinearLayout.LayoutParams(dp(76),dp(76));imageLp.bottomMargin=dp(3);
        appIcon.addView(iconFrame,imageLp);
        page.addView(appIcon);
        TextView change=txt("CHANGE ICON  ▾",9,PURPLE,true);change.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams changeLp=new LinearLayout.LayoutParams(-1,-2);changeLp.bottomMargin=dp(8);page.addView(change,changeLp);
        Runnable pickIcon=()->new AlertDialog.Builder(this).setTitle("Choose app icon").setItems(iconNames,(dialog,which)->{
            chosenIcon[0]=iconValue[which];iconBadge.setText(chosenIcon[0]);
        }).show();
        change.setOnClickListener(v->pickIcon.run());image.setOnClickListener(v->pickIcon.run());
        fieldLabel("Title / Website");
        EditText site=edit("Google, Instagram, Website...",false);
        fieldLabel("Username / Email");
        EditText user=edit("name@example.com",false);
        fieldLabel("Password");
        LinearLayout passRow=row();
        EditText pass=new EditText(this);pass.setSingleLine(true);pass.setTextColor(WHITE);pass.setHintTextColor(MUTED);pass.setHint("Enter password");pass.setTextSize(14);
        pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);pass.setBackground(solid(PANEL2,13,BORDER));padding(pass,12,8,12,8);
        passRow.addView(pass,new LinearLayout.LayoutParams(0,dp(49),1));
        TextView eye=txt("◉",15,PURPLE,true);eye.setGravity(Gravity.CENTER);
        passRow.addView(eye,new LinearLayout.LayoutParams(dp(32),dp(49)));
        final boolean[] revealPass={false};
        eye.setOnClickListener(v->{revealPass[0]=!revealPass[0];pass.setInputType(InputType.TYPE_CLASS_TEXT|
            (revealPass[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(pass.length());});
        TextView gen=txt("GENERATE",9,PURPLE,true);gen.setGravity(Gravity.CENTER);gen.setBackground(solid(PANEL,13,BORDER));padding(gen,11,11,11,11);
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-2,dp(49));gp.leftMargin=dp(4);passRow.addView(gen,gp);
        gen.setOnClickListener(v->pass.setText(generatePassword(20)));
        LinearLayout.LayoutParams prp=new LinearLayout.LayoutParams(-1,-2);prp.bottomMargin=dp(10);page.addView(passRow,prp);
        fieldLabel("Category");
        Spinner category=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,CATEGORIES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);category.setBackground(solid(PANEL2,13,BORDER));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));sp.bottomMargin=dp(10);page.addView(category,sp);
        LinearLayout cardFields=col();cardFields.setBackground(solid(PANEL,15,BORDER));padding(cardFields,12,10,12,10);
        TextView cardTitle=txt("SECURE CARD DETAILS",10,PURPLE,true);cardFields.addView(cardTitle);
        TextView cardHint=txt("These fields are encrypted inside your vault.",9,MUTED,false);cardFields.addView(cardHint);
        fieldLabelInto(cardFields,"CARDHOLDER NAME");
        EditText cardholder=editDetached("Name on card");
        cardFields.addView(cardholder,new LinearLayout.LayoutParams(-1,dp(48)));
        fieldLabelInto(cardFields,"CARD NUMBER");
        EditText cardNumber=editDetached("Card number");
        cardNumber.setInputType(InputType.TYPE_CLASS_NUMBER);cardFields.addView(cardNumber,new LinearLayout.LayoutParams(-1,dp(48)));
        fieldLabelInto(cardFields,"EXPIRY");
        EditText cardExpiry=editDetached("MM/YY");
        cardFields.addView(cardExpiry,new LinearLayout.LayoutParams(-1,dp(48)));
        fieldLabelInto(cardFields,"SECURITY CODE (CVV)");
        EditText cardCvv=editDetached("CVV");
        cardCvv.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        cardFields.addView(cardCvv,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout.LayoutParams cfp=new LinearLayout.LayoutParams(-1,-2);cfp.bottomMargin=dp(10);page.addView(cardFields,cfp);
        cardFields.setVisibility(View.GONE);
        category.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){cardFields.setVisibility("Cards".equals(CATEGORIES[pos])?View.VISIBLE:View.GONE);}
        });
        fieldLabel("Authenticator Secret (Optional · 2FA)");
        EditText totpSecret=edit("Base32 secret from the service",false);
        fieldLabel("Notes (Optional)");
        EditText notes=edit("Personal note...",false);
        notes.setSingleLine(false);notes.setMinLines(2);notes.setGravity(Gravity.TOP|Gravity.LEFT);
        if(old!=null){
            site.setText(old.optString("site"));user.setText(old.optString("username"));pass.setText(old.optString("password"));notes.setText(old.optString("notes"));
            cardholder.setText(old.optString("cardholder"));cardNumber.setText(old.optString("cardNumber"));cardExpiry.setText(old.optString("cardExpiry"));cardCvv.setText(old.optString("cardCvv"));totpSecret.setText(old.optString("totpSecret"));
            String current=old.optString("category","Login");
            for(int i=0;i<CATEGORIES.length;i++)if(CATEGORIES[i].equalsIgnoreCase(current))category.setSelection(i);
        }
        button("SAVE PASSWORD",()->{
            String selected=category.getSelectedItem().toString();
            boolean noteOnly="Notes".equals(selected),cardOnly="Cards".equals(selected);
            if(site.getText().toString().trim().isEmpty()||(pass.getText().toString().isEmpty()&&(!noteOnly&&!cardOnly||notes.getText().toString().trim().isEmpty()&&!cardOnly))){toast(noteOnly?"A title and note are required.":(cardOnly?"A card title is required.":"Website and password are required."));return;}
            if(!totpSecret.getText().toString().trim().isEmpty()&&!isValidBase32(totpSecret.getText().toString())){toast("Authenticator secret must be a valid Base32 key.");return;}
            try{
                JSONObject item=new JSONObject();
                item.put("site",site.getText().toString().trim());item.put("username",user.getText().toString().trim());
                item.put("password",pass.getText().toString());item.put("category",category.getSelectedItem().toString());
                item.put("notes",notes.getText().toString());item.put("icon",chosenIcon[0]);
                item.put("cardholder",cardholder.getText().toString().trim());item.put("cardNumber",cardNumber.getText().toString().replace(" ",""));item.put("cardExpiry",cardExpiry.getText().toString().trim());item.put("cardCvv",cardCvv.getText().toString().trim());
                item.put("totpSecret",totpSecret.getText().toString().trim().replace(" ","").toUpperCase(Locale.US));
                if(old!=null&&old.optBoolean("favorite",false))item.put("favorite",true);
                if(index>=0)records.put(index,item);else records.put(item);
                persist();hideKeyboard();if(lastFromVault)showVault();else showHome();toast("Password encrypted and saved.");
            }catch(Exception e){toast("Could not save this password.");}
        });
        ghostButton("CANCEL",()->{if(lastFromVault)showVault();else showHome();});
    }

    private void showDetails(int index) {
        JSONObject o=records.optJSONObject(index);if(o==null)return;
        initInner("Password Details",o.optString("category","Login"),()->{if(lastFromVault)showVault();else showHome();});
        LinearLayout app=col();app.setGravity(Gravity.CENTER);app.setBackground(solid(PANEL,17,BORDER));padding(app,14,14,14,14);
        TextView monogram=txt(o.optString("icon",o.optString("site","?").substring(0,1).toUpperCase(Locale.US)),24,WHITE,true);
        monogram.setGravity(Gravity.CENTER);monogram.setBackground(solid(categoryColor(o.optString("category","Login")),17,0));
        app.addView(monogram,new LinearLayout.LayoutParams(dp(54),dp(54)));
        TextView name=txt(o.optString("site"),15,WHITE,true);name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(9);app.addView(name,np);
        app.addView(txt(o.optString("category","Login"),9,PURPLE,true));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.bottomMargin=dp(12);page.addView(app,ap);
        detailsField("USERNAME",o.optString("username"),()->copy(o.optString("username")));
        final boolean[] reveal={false};
        detailsField("PASSWORD","••••••••••••",()->copy(o.optString("password")));
        TextView show=txt("◉  REVEAL PASSWORD",10,PURPLE,true);show.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sh=new LinearLayout.LayoutParams(-1,dp(38));page.addView(show,sh);
        show.setOnClickListener(v->{reveal[0]=!reveal[0];show.setText(reveal[0]?"◉  HIDE PASSWORD":"◉  REVEAL PASSWORD");((TextView)((LinearLayout)page.getChildAt(page.getChildCount()-2)).getChildAt(1)).setText(reveal[0]?o.optString("password"):"••••••••••••");});
        detailsField("WEBSITE",o.optString("site"),()->openWebsite(o.optString("site")));
        if("Cards".equalsIgnoreCase(o.optString("category"))){
            detailsField("CARDHOLDER",o.optString("cardholder"),()->copy(o.optString("cardholder")));
            detailsField("CARD NUMBER",maskCard(o.optString("cardNumber")),()->copy(o.optString("cardNumber")));
            detailsField("EXPIRY",o.optString("cardExpiry"),()->copy(o.optString("cardExpiry")));
            detailsField("CVV","•••",()->copy(o.optString("cardCvv")));
        }
        if(!o.optString("totpSecret").isEmpty()){
            String code=totpCode(o.optString("totpSecret"),System.currentTimeMillis()/30000L);
            card("TWO-FA AUTHENTICATOR",code+"  ·  refreshes every 30 seconds","2FA",null);
            button("COPY 2FA CODE",()->copy(totpCode(o.optString("totpSecret"),System.currentTimeMillis()/30000L)));
        }
        if(!o.optString("notes").isEmpty())card("NOTES",o.optString("notes"),null,null);
        button("COPY USERNAME",()->copy(o.optString("username")));
        button("COPY PASSWORD",()->copy(o.optString("password")));
        button("OPEN WEBSITE",()->openWebsite(o.optString("site")));
        ghostButton("EDIT",()->showEditor(index));
        TextView del=txt("DELETE",11,RED,true);del.setGravity(Gravity.CENTER);del.setBackground(solid(0xFF351622,23,0));padding(del,10,12,10,12);page.addView(del);
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete password?")
            .setMessage("This item will move to Recently Deleted. You can restore it for 30 days.")
            .setNegativeButton("CANCEL",null).setPositiveButton("MOVE TO TRASH",(d,w)->{try{JSONObject moved=new JSONObject(records.optJSONObject(index).toString());moved.put("deletedAt",System.currentTimeMillis());records.put(index,moved);persist();showVault();toast("Moved to Recently Deleted.");}catch(Exception ex){toast("Could not delete item.");}}).show());
    }
    private void showTrash(){
        initInner("Recently Deleted","Restore items or permanently erase them",()->showSettings());
        card("30-DAY RECOVERY","Items moved here stay encrypted in your vault. They are automatically removed after 30 days when you open this screen.","PRIVATE",null);
        long now=System.currentTimeMillis(); boolean changed=false; int shown=0;
        for(int i=records.length()-1;i>=0;i--){
            JSONObject item=records.optJSONObject(i); if(!isDeleted(item)) continue;
            long deleted=item.optLong("deletedAt",now);
            if(now-deleted>30L*24L*60L*60L*1000L){records.remove(i);changed=true;continue;}
            shown++; final int idx=i; final JSONObject saved=item;
            LinearLayout tile=col();tile.setBackground(solid(PANEL,15,BORDER));padding(tile,12,11,12,11);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.bottomMargin=dp(8);page.addView(tile,tp);
            tile.addView(txt(saved.optString("site","Untitled"),13,WHITE,true));
            tile.addView(txt(saved.optString("username","No username")+" · "+saved.optString("category","Login"),9,MUTED,false));
            LinearLayout actions=row();LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(9);tile.addView(actions,ap);
            TextView restore=txt("RESTORE",10,GREEN,true);restore.setGravity(Gravity.CENTER);restore.setBackground(solid(0xFF10372F,18,0));padding(restore,12,9,12,9);actions.addView(restore,new LinearLayout.LayoutParams(0,dp(38),1));
            View gap=new View(this);actions.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
            TextView erase=txt("DELETE FOREVER",10,RED,true);erase.setGravity(Gravity.CENTER);erase.setBackground(solid(0xFF351622,18,0));padding(erase,10,9,10,9);actions.addView(erase,new LinearLayout.LayoutParams(0,dp(38),1));
            restore.setOnClickListener(v->{try{JSONObject restored=new JSONObject(records.optJSONObject(idx).toString());restored.remove("deletedAt");records.put(idx,restored);persist();showTrash();toast("Item restored.");}catch(Exception e){toast("Restore failed.");}});
            erase.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete permanently?").setMessage("This cannot be undone.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE",(d,w)->{records.remove(idx);persist();showTrash();}).show());
        }
        if(changed)persist();
        if(shown==0)card("TRASH IS EMPTY","Deleted items will appear here so you can restore them if needed.","EMPTY",null);
        else button("EMPTY TRASH",()->new AlertDialog.Builder(this).setTitle("Empty Recently Deleted?").setMessage("All items here will be permanently erased from the encrypted vault.").setNegativeButton("CANCEL",null).setPositiveButton("EMPTY",(d,w)->{for(int i=records.length()-1;i>=0;i--)if(isDeleted(records.optJSONObject(i)))records.remove(i);persist();showTrash();}).show());
    }

    private void fieldLabelInto(LinearLayout target,String label){
        TextView t=txt(label,8,SOFT,true);t.setLetterSpacing(.08f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(4);target.addView(t,p);
    }
    private EditText editDetached(String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setHint(hint);
        e.setTextSize(13);e.setBackground(solid(PANEL2,12,BORDER));padding(e,12,7,12,7);
        if(Build.VERSION.SDK_INT>=29)e.setTextCursorDrawable(null);return e;
    }
    private String maskCard(String number){
        if(number==null||number.isEmpty())return "Not set";
        String digits=number.replaceAll("\\D","");return "•••• •••• •••• "+digits.substring(Math.max(0,digits.length()-4));
    }
    private boolean isValidBase32(String secret){
        String x=secret.toUpperCase(Locale.US).replace("=","").replace(" ","");
        return x.matches("[A-Z2-7]{16,128}");
    }
    private byte[] decodeBase32(String input)throws Exception{
        String s=input.toUpperCase(Locale.US).replace("=","").replace(" ","");
        java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();int buffer=0,bits=0;
        for(int i=0;i<s.length();i++){char c=s.charAt(i);int val=c>='A'&&c<='Z'?c-'A':(c>='2'&&c<='7'?c-'2'+26:-1);if(val<0)throw new Exception("Invalid Base32");
            buffer=(buffer<<5)|val;bits+=5;if(bits>=8){bits-=8;out.write((buffer>>bits)&255);}}
        return out.toByteArray();
    }
    private String totpCode(String secret,long counter){
        try{
            byte[] key=decodeBase32(secret);byte[] msg=ByteBuffer.allocate(8).putLong(counter).array();
            Mac mac=Mac.getInstance("HmacSHA1");mac.init(new SecretKeySpec(key,"HmacSHA1"));byte[] hash=mac.doFinal(msg);
            int off=hash[hash.length-1]&15;int bin=((hash[off]&127)<<24)|((hash[off+1]&255)<<16)|((hash[off+2]&255)<<8)|(hash[off+3]&255);
            return String.format(Locale.US,"%06d",bin%1000000);
        }catch(Exception e){return "------";}
    }
    private void showAuthenticator(){
        initInner("2FA Authenticator","Time-based verification codes",()->showSecurity());
        card("AUTHENTICATOR","One-time codes are generated on this device from the encrypted Base32 secret. SPY VAULT does not transmit these secrets.","LOCAL",null);
        int count=0;
        for(int i=0;i<records.length();i++){
            JSONObject o=records.optJSONObject(i);if(o==null||o.optString("totpSecret").isEmpty())continue;
            count++;String secret=o.optString("totpSecret");String code=totpCode(secret,System.currentTimeMillis()/30000L);
            final int ix=i;
            LinearLayout item=col();item.setBackground(solid(PANEL,16,BORDER));padding(item,14,12,14,12);
            LinearLayout header=row();header.addView(txt(o.optString("site","Authenticator"),12,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
            header.addView(txt("TOTP",9,PURPLE,true));item.addView(header);
            TextView value=txt(code,25,0xFFD7F76B,true);value.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);value.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,-2);vp.topMargin=dp(10);vp.bottomMargin=dp(5);item.addView(value,vp);
            TextView timer=txt("Refreshes in "+(30-(int)(System.currentTimeMillis()/1000%30))+" seconds",9,MUTED,false);timer.setGravity(Gravity.CENTER);item.addView(timer);
            buttonInto(item,"COPY CODE",()->copy(totpCode(secret,System.currentTimeMillis()/30000L)));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.bottomMargin=dp(9);page.addView(item,ip);
        }
        if(count==0)card("NO AUTHENTICATORS YET","Open a saved login, choose Edit, and add its Base32 authenticator secret to enable one-time codes.","",null);
        ghostButton("BACK TO SECURITY CENTER",()->showSecurity());
    }
    private void buttonInto(LinearLayout parent,String label,Runnable action){
        TextView b=txt(label,10,WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(gradient(20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(40));p.topMargin=dp(8);parent.addView(b,p);b.setOnClickListener(v->action.run());
    }

    private void detailsField(String label,String value,Runnable copyAction){
        LinearLayout c=col();c.setBackground(solid(PANEL,13,BORDER));padding(c,12,10,12,10);
        TextView h=txt(label,8,MUTED,true);c.addView(h);
        LinearLayout r=row();r.addView(txt(value,11,WHITE,false),new LinearLayout.LayoutParams(0,-2,1));
        TextView cp=txt("▢",15,PURPLE,true);r.addView(cp);cp.setOnClickListener(v->copyAction.run());c.addView(r);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);page.addView(c,p);
    }
    private void openWebsite(String site){
        try{String u=site;if(!u.startsWith("http://")&&!u.startsWith("https://"))u="https://"+u;startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}
        catch(Exception e){toast("Could not open website.");}
    }

    private void showGenerator() {
        initInner("Password Generator","Create unique passwords",()->showHome());
        LinearLayout outCard=col();outCard.setBackground(solid(PANEL,18,BORDER));padding(outCard,15,17,15,17);
        TextView out=txt(generatePassword(16),17,0xFFD7F76B,true);out.setGravity(Gravity.CENTER);
        outCard.addView(out);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2);op.bottomMargin=dp(18);page.addView(outCard,op);
        TextView len=txt("Length: 16",11,SOFT,true);page.addView(len);
        SeekBar seek=new SeekBar(this);seek.setMax(28);seek.setProgress(12);
        seek.setProgressTintList(ColorStateList.valueOf(PURPLE));seek.setThumbTintList(ColorStateList.valueOf(PINK));
        page.addView(seek,new LinearLayout.LayoutParams(-1,dp(40)));
        int[] length={16};
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean from){length[0]=4+p;len.setText("Length: "+length[0]);}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        CheckBox upper=option("Uppercase (A-Z)",true),lower=option("Lowercase (a-z)",true),numbers=option("Numbers (0-9)",true),symbols=option("Special characters (!@#)",true);
        Runnable generate=()->{
            String chars="";if(upper.isChecked())chars+="ABCDEFGHJKLMNPQRSTUVWXYZ";if(lower.isChecked())chars+="abcdefghijkmnopqrstuvwxyz";
            if(numbers.isChecked())chars+="23456789";if(symbols.isChecked())chars+="!@#$%&*_-+";
            if(chars.isEmpty()){toast("Select at least one character group.");return;}
            out.setText(generatePassword(length[0],chars));
        };
        button("GENERATE",generate);ghostButton("COPY PASSWORD",()->copy(out.getText().toString()));
    }
    private CheckBox option(String value,boolean checked){
        CheckBox c=new CheckBox(this);c.setText(value);c.setTextColor(SOFT);c.setTextSize(11);c.setChecked(checked);
        c.setButtonTintList(ColorStateList.valueOf(PURPLE));page.addView(c);return c;
    }

    private void showCategories() {
        initInner("Categories","Choose a vault category",()->showVault());
        String[] cats={"All Items","Logins","Notes","Cards","Social Media","Work","Banking","Shopping","Gaming"};
        String[] icon={"▦","◈","◎","▤","▣","▥","▣","▧","◉","◌"};
        for(int i=0;i<cats.length;i++){
            String cat=cats[i];String actual=cat.equals("All Items")?"All":(cat.equals("Logins")?"Login":cat);
            int count=0;for(int k=0;k<records.length();k++){JSONObject o=records.optJSONObject(k);if(o!=null&&!isDeleted(o)&&(actual.equals("All")||actual.equalsIgnoreCase(o.optString("category","Login"))))count++;}
            final int n=i;
            LinearLayout r=row();r.setBackground(solid(PANEL,15,BORDER));padding(r,13,12,13,12);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(8);page.addView(r,rp);
            TextView ic=txt(icon[i],17,WHITE,true);ic.setGravity(Gravity.CENTER);ic.setBackground(solid(categoryColor(cat),12,0));r.addView(ic,new LinearLayout.LayoutParams(dp(38),dp(38)));
            LinearLayout d=col();padding(d,10,0,0,0);d.addView(txt(cat,12,WHITE,true));d.addView(txt(count+" items",9,MUTED,false));
            r.addView(d,new LinearLayout.LayoutParams(0,-2,1));r.addView(txt("›",22,MUTED,true));
            r.setOnClickListener(v->{selectedCategory=actual;showVault();});
        }
    }

    private void showDrawer(){
        final Dialog dialog=new Dialog(this);
        LinearLayout panel=col();panel.setBackground(solid(0xFF101020,26,0xFF59318A));
        panel.setElevation(dp(18));padding(panel,17,17,17,15);
        LinearLayout brand=row();
        ImageView logo=new ImageView(this);int logoId=getResources().getIdentifier("spy_vault_shield","drawable",getPackageName());
        if(logoId!=0)logo.setImageResource(logoId);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout names=col();padding(names,10,0,0,0);names.addView(txt("SPY VAULT",18,WHITE,true));
        TextView sub=txt("YOUR PRIVATE VAULT",8,MUTED,true);sub.setLetterSpacing(.13f);names.addView(sub);
        brand.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView secure=txt("● SECURE",9,GREEN,true);secure.setBackground(solid(0xFF10372F,20,0));padding(secure,10,7,10,7);brand.addView(secure);
        panel.addView(brand);
        LinearLayout banner=col();banner.setBackground(solid(0xFF1A1230,16,0xFF3E2462));padding(banner,13,11,13,11);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(12);bp.bottomMargin=dp(12);panel.addView(banner,bp);
        banner.addView(txt("PRIVATE. ENCRYPTED. YOURS.",10,0xFFE2B7FF,true));
        banner.addView(txt("Your vault stays protected on this device.",10,SOFT,false));
        String[] titles={"Home","Vault","Password Generator","Categories","Settings","Security Center","Backup & Sync","About SPY VAULT"};
        String[] icons={"⌂","▣","✳","▦","◈","♢","☁","ⓘ"};
        Runnable[] actions={()->showHome(),()->showVault(),()->showGenerator(),()->showCategories(),()->showSettings(),()->showSecurity(),()->showBackup(),()->showAbout()};
        for(int i=0;i<titles.length;i++){
            final Runnable action=actions[i];
            LinearLayout item=row();item.setBackground(solid(0xFF17182A,14,0xFF29213F));padding(item,12,8,12,8);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(47));ip.bottomMargin=dp(6);panel.addView(item,ip);
            TextView ic=txt(icons[i],18,PINK,true);ic.setGravity(Gravity.CENTER);ic.setBackground(solid(0xFF2A1742,11,0));item.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(34)));
            TextView label=txt(titles[i],12,WHITE,true);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1);tl.leftMargin=dp(12);item.addView(label,tl);
            item.addView(txt("›",22,MUTED,true));item.setOnClickListener(v->{dialog.dismiss();action.run();});
        }
        TextView close=txt("CLOSE MENU",11,PURPLE,true);close.setGravity(Gravity.CENTER);close.setBackground(solid(0xFF1B1430,22,0xFF543078));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(44));cp.topMargin=dp(7);panel.addView(close,cp);close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(panel);Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams a=w.getAttributes();a.width=getResources().getDisplayMetrics().widthPixels-dp(34);a.height=-2;a.gravity=Gravity.CENTER;a.dimAmount=.78f;w.setAttributes(a);}
        dialog.show();if(dialog.getWindow()!=null){dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-dp(34),-2);dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);}
    }

    private void showSettings() {
        initInner("Settings","Customize your vault",()->showHome());
        settingsRow("Security Center","Master password, biometrics and auto-lock","◈",()->showSecurity());
        settingsRow("Backup & Sync","Encrypted backup and restore","☁",()->showBackup());
        settingsRow("Appearance","Theme, accent colors and text size","◐",()->showAppearance());
        settingsRow("Auto-Lock","Lock after "+autoLockMinutes+" minutes","◷",()->chooseAutoLock());
        settingsRow("Export Data","Create an encrypted vault backup","⇧",()->showBackup());
        settingsRow("Recently Deleted",deletedCount()+" items · restore within 30 days","▤",()->showTrash());
        settingsRow("Categories","Organize saved credentials","▦",()->showCategories());
        settingsRow("About SPY VAULT","App version and privacy information","ⓘ",()->showAbout());
        button("LOCK VAULT NOW",()->{lockVault();showGate();});
    }
    private void settingsRow(String title,String detail,String icon,Runnable action){
        LinearLayout r=row();r.setBackground(solid(PANEL,15,BORDER));padding(r,13,13,13,13);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(8);page.addView(r,rp);
        TextView ic=txt(icon,16,PINK,true);ic.setGravity(Gravity.CENTER);ic.setBackground(solid(0xFF28183C,12,0));r.addView(ic,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout d=col();padding(d,10,0,0,0);d.addView(txt(title,12,WHITE,true));d.addView(txt(detail,9,MUTED,false));
        r.addView(d,new LinearLayout.LayoutParams(0,-2,1));r.addView(txt("›",22,MUTED,true));r.setOnClickListener(v->action.run());
    }

    private void showSecurity() {
        initInner("Security Center","Your vault protection",()->showSettings());
        LinearLayout center=col();center.setGravity(Gravity.CENTER);center.setBackground(solid(PANEL,18,BORDER));padding(center,15,16,15,16);
        ImageView shield=new ImageView(this);int id=getResources().getIdentifier("onboard_lock","drawable",getPackageName());if(id!=0)shield.setImageResource(id);
        shield.setScaleType(ImageView.ScaleType.CENTER_CROP);shield.setBackground(solid(0xFF0B0A18,18,BORDER));shield.setClipToOutline(true);
        center.addView(shield,new LinearLayout.LayoutParams(dp(180),dp(150)));
        TextView ok=txt("●  Your Vault is Encrypted",13,GREEN,true);ok.setGravity(Gravity.CENTER);center.addView(ok);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(13);page.addView(center,cp);
        settingsRow("Master Password","Set and protect your vault key","◈",()->changeMasterPassword());
        settingsRow("Fingerprint Unlock",hasBiometricKey()?"Enabled on this device":"Not configured","◎",()->enableBiometric());
        settingsRow("Auto-Lock",autoLockMinutes+" minutes","◷",()->chooseAutoLock());
        settingsRow("Password Health","Check weak and reused passwords","✧",()->showSecurityAudit());
        settingsRow("Password Breach Check","Check a password using a privacy-preserving range lookup","◉",()->showBreachCheck());
        settingsRow("2FA Authenticator","Generate time-based verification codes","◉",()->showAuthenticator());
        settingsRow("Clipboard Protection","Auto-clear copied values after 30 seconds","▣",()->toast("Clipboard clearing is best-effort."));
        settingsRow("E2E Cloud Recovery","Sign in to sync or restore your encrypted vault","☁",()->showCloudRecovery());
        ghostButton("BACK TO SETTINGS",()->showSettings());
    }

    private void showSecurityAudit(){
        initInner("Password Health","On-device security audit",()->showSecurity());
        int weak=0,reused=0,shortOnes=0;
        ArrayList<String> seen=new ArrayList<>();
        boolean[] duplicate=new boolean[records.length()];
        for(int i=0;i<records.length();i++){
            JSONObject o=records.optJSONObject(i);if(o==null||isDeleted(o))continue;
            String pass=o.optString("password","");
            if(pass.length()>0&&(pass.length()<12||!pass.matches("(?s).*[A-Za-z].*")||!pass.matches("(?s).*\\d.*"))){weak++;if(pass.length()<12)shortOnes++;}
            if(!pass.isEmpty()){
                for(int j=0;j<i;j++){JSONObject prev=records.optJSONObject(j);if(prev!=null&&!isDeleted(prev)&&pass.equals(prev.optString("password",""))){duplicate[i]=true;break;}}
                if(duplicate[i])reused++;
            }
        }
        int score=activeCount()==0?100:Math.max(0,100-(weak*12)-(reused*18));
        LinearLayout scoreCard=col();scoreCard.setGravity(Gravity.CENTER);scoreCard.setBackground(solid(PANEL,20,BORDER));padding(scoreCard,18,18,18,18);
        TextView orb=txt(score>=80?"✦":score>=50?"◈":"!",34,score>=80?GREEN:(score>=50?0xFFFFC857:RED),true);orb.setGravity(Gravity.CENTER);
        scoreCard.addView(orb);
        TextView scoreText=txt(activeCount()==0?"Ready for your first audit":score+"/100  ·  Security score",17,WHITE,true);scoreText.setGravity(Gravity.CENTER);scoreCard.addView(scoreText);
        TextView detail=txt(activeCount()==0?"Save passwords to receive local security recommendations.":"Analysis runs only on this device. Password values are never displayed or uploaded.",10,SOFT,false);detail.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp0=new LinearLayout.LayoutParams(-1,-2);dp0.topMargin=dp(6);scoreCard.addView(detail,dp0);
        LinearLayout.LayoutParams scp=new LinearLayout.LayoutParams(-1,-2);scp.bottomMargin=dp(13);page.addView(scoreCard,scp);
        LinearLayout stats=row();
        stats.addView(auditTile("WEAK PASSWORDS",String.valueOf(weak),weak==0?GREEN:RED),new LinearLayout.LayoutParams(0,dp(88),1));
        View gap=new View(this);stats.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        stats.addView(auditTile("REUSED PASSWORDS",String.valueOf(reused),reused==0?GREEN:0xFFFFC857),new LinearLayout.LayoutParams(0,dp(88),1));
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2);stp.bottomMargin=dp(13);page.addView(stats,stp);
        card("WHAT WE CHECK","Weak passwords are short or lack a mix of letters and numbers. Reused passwords are exact matches across saved entries.","LOCAL",null);
        TextView title=txt("RECOMMENDED ACTIONS",10,SOFT,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(10);tp.bottomMargin=dp(8);page.addView(title,tp);
        int flagged=0;
        for(int i=0;i<records.length();i++){
            JSONObject o=records.optJSONObject(i);if(o==null||isDeleted(o))continue;String pass=o.optString("password","");
            boolean isWeak=pass.length()>0&&(pass.length()<12||!pass.matches("(?s).*[A-Za-z].*")||!pass.matches("(?s).*\\d.*"));
            boolean isReused=duplicate[i];
            if(!isWeak&&!isReused)continue;flagged++;
            String reason=(isWeak?"Weak password":"")+(isWeak&&isReused?" · ":"")+(isReused?"Reused password":"");
            final int ix=i;
            LinearLayout item=row();item.setBackground(solid(PANEL,14,BORDER));padding(item,12,10,12,10);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.bottomMargin=dp(7);page.addView(item,ip);
            TextView ico=txt("◈",17,PINK,true);ico.setGravity(Gravity.CENTER);ico.setBackground(solid(0xFF2A1742,11,0));item.addView(ico,new LinearLayout.LayoutParams(dp(36),dp(36)));
            LinearLayout labels=col();padding(labels,10,0,0,0);labels.addView(txt(o.optString("site","Saved item"),12,WHITE,true));labels.addView(txt(reason,9,RED,false));
            item.addView(labels,new LinearLayout.LayoutParams(0,-2,1));item.addView(txt("›",21,MUTED,true));item.setOnClickListener(v->showDetails(ix));
        }
        if(flagged==0)card("ALL CLEAR","No weak or reused saved passwords were detected by this basic local check.","✓",null);
        ghostButton("BACK TO SECURITY CENTER",()->showSecurity());
    }
    private void showBreachCheck(){
        initInner("Password Breach Check","Privacy-preserving online check",()->showSecurity());
        card("HOW IT PROTECTS YOU","Your password is hashed on this device. Only the first 5 characters of its SHA-1 hash are sent; the full password and remaining hash are never sent.","K-ANONYMITY",null);
        fieldLabel("PASSWORD TO CHECK");
        EditText input=secretEdit("Enter a password to check");
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(54));fp.bottomMargin=dp(12);page.addView(input,fp);
        TextView result=txt("No check performed yet.",11,SOFT,false);result.setGravity(Gravity.CENTER);
        LinearLayout resultCard=col();resultCard.setBackground(solid(PANEL,16,BORDER));padding(resultCard,14,14,14,14);resultCard.addView(result);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(12);page.addView(resultCard,rp);
        button("CHECK PASSWORD",()->{
            String value=input.getText().toString();
            if(value.isEmpty()){input.setError("Enter a password first");return;}
            result.setText("Checking securely…");
            new Thread(()->{
                HttpURLConnection conn=null;
                try{
                    byte[] digest=MessageDigest.getInstance("SHA-1").digest(value.getBytes("UTF-8"));
                    StringBuilder hex=new StringBuilder();for(byte b:digest)hex.append(String.format(Locale.US,"%02X",b&255));
                    String hash=hex.toString(),prefix=hash.substring(0,5),suffix=hash.substring(5);
                    URL url=new URL("https://api.pwnedpasswords.com/range/"+prefix);
                    conn=(HttpURLConnection)url.openConnection();conn.setRequestMethod("GET");conn.setConnectTimeout(10000);conn.setReadTimeout(12000);conn.setRequestProperty("Add-Padding","true");conn.setRequestProperty("User-Agent","SPY-VAULT-Password-Health");
                    int code=conn.getResponseCode();if(code!=200)throw new IOException("Service unavailable ("+code+")");
                    BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"));String line;long found=0;
                    while((line=reader.readLine())!=null){int colon=line.indexOf(':');if(colon>0&&line.substring(0,colon).trim().equalsIgnoreCase(suffix)){try{found=Long.parseLong(line.substring(colon+1).trim());}catch(Exception ignored){}break;}}
                    reader.close();final long count=found;
                    runOnUiThread(()->{result.setText(count>0?"⚠  Found in known breach datasets · "+count+" occurrences. Change this password anywhere you use it.":"✓  No match found in the checked breach dataset. This does not guarantee the password has never been exposed.");result.setTextColor(count>0?RED:GREEN);input.setText("");});
                }catch(Exception ex){runOnUiThread(()->{result.setText("Could not complete the check. Try again when internet is available.");result.setTextColor(0xFFFFC857);});}
                finally{if(conn!=null)conn.disconnect();}
            }).start();
        });
        card("IMPORTANT","This is an optional online check using the Have I Been Pwned range API. The first 5 SHA-1 hash characters can be observed by the service; the password itself is not transmitted. Avoid checking passwords on untrusted networks.","PRIVACY",null);
        ghostButton("BACK TO SECURITY CENTER",()->showSecurity());
    }

    private LinearLayout auditTile(String label,String value,int color){
        LinearLayout tile=col();tile.setBackground(solid(PANEL,15,BORDER));padding(tile,12,11,12,11);
        tile.addView(txt(value,22,color,true));tile.addView(txt(label,8,MUTED,true));return tile;
    }

    private void changeMasterPassword(){
        final Dialog dialog=new Dialog(this);
        LinearLayout outer=col();outer.setBackground(solid(0xFF101426,24,0xFF49306E));padding(outer,18,18,18,16);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        LinearLayout body=col();scroll.addView(body);
        LinearLayout hero=row();hero.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge=txt("◈",22,PINK,true);badge.setGravity(Gravity.CENTER);badge.setBackground(solid(0xFF2B1747,15,0xFF59318A));
        hero.addView(badge,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout head=col();padding(head,12,0,0,0);
        head.addView(txt("Change Master Password",18,WHITE,true));
        head.addView(txt("Update the key that protects your vault",10,SOFT,false));
        hero.addView(head,new LinearLayout.LayoutParams(0,-2,1));body.addView(hero);
        LinearLayout warning=col();warning.setBackground(solid(0xFF1B1730,14,0xFF382653));padding(warning,11,10,11,10);
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);wp.topMargin=dp(14);wp.bottomMargin=dp(12);body.addView(warning,wp);
        warning.addView(txt("PRIVATE BY DESIGN",9,PURPLE,true));
        warning.addView(txt("Your vault is re-encrypted locally. Your saved passwords are not uploaded.",10,SOFT,false));
        final EditText old=dialogField("Current master password");
        final EditText n1=dialogField("New master password · 12+ characters");
        final EditText n2=dialogField("Confirm new master password");
        addDialogField(body,"CURRENT PASSWORD",old);
        addDialogField(body,"NEW PASSWORD",n1);
        addDialogField(body,"CONFIRM NEW PASSWORD",n2);
        final TextView strength=txt("Password strength · enter a new password",10,MUTED,true);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(9);body.addView(strength,sp);
        final View meter=new View(this);meter.setBackground(solid(0xFF34364A,4,0));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(5));mp.topMargin=dp(7);mp.bottomMargin=dp(5);body.addView(meter,mp);
        n1.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence c,int st,int count,int after){}
            public void onTextChanged(CharSequence c,int st,int before,int count){
                String v=c.toString();int score=0;
                if(v.length()>=12)score++;if(v.matches("(?s).*[A-Za-z].*")&&v.matches("(?s).*\\d.*"))score++;
                if(v.matches("(?s).*[^A-Za-z0-9].*"))score++;
                int color=score==3?GREEN:(score==2?0xFFFFC857:RED);
                strength.setText(score==0?"Password strength · weak":score==1?"Password strength · fair":score==2?"Password strength · good":"Password strength · strong");
                strength.setTextColor(color);meter.setBackground(solid(color,4,0));
                LinearLayout.LayoutParams m=(LinearLayout.LayoutParams)meter.getLayoutParams();m.width=score==0?dp(35):score==1?dp(100):score==2?dp(190):-1;meter.setLayoutParams(m);
            }
            public void afterTextChanged(Editable e){}
        });
        LinearLayout actions=row();actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel=txt("CANCEL",11,SOFT,true);cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(solid(0xFF191D30,22,BORDER));padding(cancel,14,12,14,12);
        TextView update=txt("UPDATE PASSWORD",11,WHITE,true);update.setGravity(Gravity.CENTER);update.setBackground(gradient(22));padding(update,16,12,16,12);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(46),1);ap.topMargin=dp(16);ap.rightMargin=dp(7);actions.addView(cancel,ap);
        LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(0,dp(46),1);up.topMargin=dp(16);up.leftMargin=dp(7);actions.addView(update,up);
        // Keep actions pinned outside the scroll area so they never disappear below the dialog.
        LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(-1,0,1f);
        outer.addView(scroll,scrollLp);
        LinearLayout actionBar=row();actionBar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams barLp=new LinearLayout.LayoutParams(-1,-2);
        barLp.topMargin=dp(10);
        actionBar.addView(actions,barLp);
        outer.addView(actionBar,new LinearLayout.LayoutParams(-1,-2));
        dialog.setContentView(outer);
        cancel.setOnClickListener(v->dialog.dismiss());
        update.setOnClickListener(v->{
            String a=n1.getText().toString(),b=n2.getText().toString();
            if(old.getText().length()==0){old.setError("Enter your current password");return;}
            if(a.length()<12){n1.setError("Use at least 12 characters");return;}
            if(!a.matches("(?s).*[A-Za-z].*")||!a.matches("(?s).*\\d.*")){n1.setError("Use both letters and numbers");return;}
            if(!a.equals(b)){n2.setError("Passwords do not match");return;}
            try{
                VaultData vaultData=readVault(old.getText().toString().toCharArray());
                byte[] salt=randomBytes(SALT_LEN);byte[] key=derive(a.toCharArray(),salt);
                saveVault(salt,key,vaultData.records);activeKey=key;records=vaultData.records;
                deleteBiometricMaterial();dialog.dismiss();toast("Master password updated. Set up fingerprint unlock again if needed.");showSecurity();
            }catch(Exception ex){old.setError("Current password is incorrect");}
        });
        dialog.show();
        Window w=dialog.getWindow();
        if(w!=null){
            w.setBackgroundDrawableResource(android.R.color.transparent);
            int screenH=getResources().getDisplayMetrics().heightPixels;
            int screenW=getResources().getDisplayMetrics().widthPixels;
            // Keep the complete pinned action row above system navigation; only fields scroll.
            int safeH=(int)(screenH*0.78f);
            int maxH=Math.min(dp(640),safeH);
            w.setLayout((int)(screenW*0.92f),Math.max(dp(420),maxH));
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
    }
    private EditText dialogField(String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setHint(hint);
        e.setTextSize(14);e.setPadding(dp(13),dp(12),dp(13),dp(12));
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setBackground(solid(0xFF1A2036,13,0xFF393052));e.setMinHeight(dp(50));return e;
    }
    private void addDialogField(LinearLayout parent,String label,EditText input){
        TextView t=txt(label,9,SOFT,true);t.setLetterSpacing(.08f);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(9);tp.bottomMargin=dp(5);parent.addView(t,tp);
        parent.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    private void chooseAutoLock(){
        String[] vals={"Immediately","1 minute","5 minutes","10 minutes","15 minutes"};
        int[] mins={0,1,5,10,15};
        Dialog dialog=new Dialog(this);
        LinearLayout box=col();box.setBackground(solid(PANEL,22,BORDER));padding(box,20,18,20,14);
        TextView title=txt("Auto-Lock",21,WHITE,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.bottomMargin=dp(12);box.addView(title,tp);
        for(int i=0;i<vals.length;i++){
            final int which=i;
            LinearLayout option=row();padding(option,2,9,2,9);
            TextView radio=txt(i==indexAutoLock()?"◉":"○",21,i==indexAutoLock()?PURPLE:MUTED,true);
            option.addView(radio,new LinearLayout.LayoutParams(dp(36),dp(38)));
            TextView label=txt(vals[i],16,WHITE,false);option.addView(label,new LinearLayout.LayoutParams(0,dp(38),1));
            box.addView(option);
            option.setOnClickListener(v->{
                autoLockMinutes=mins[which];
                getPreferences(0).edit().putInt("autolock",autoLockMinutes).apply();
                dialog.dismiss();showSecurity();
            });
        }
        TextView cancel=txt("CANCEL",12,PURPLE,true);cancel.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(44));cp.topMargin=dp(8);box.addView(cancel,cp);
        cancel.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(box);
        Window w=dialog.getWindow();
        if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(40),dp(420)),-2);}
        dialog.show();
        if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);dialog.getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(40),dp(420)),-2);}
    }
    private int indexAutoLock(){int[] a={0,1,5,10,15};for(int i=0;i<a.length;i++)if(a[i]==autoLockMinutes)return i;return 2;}

    private void showBackup() {
        initInner("Backup & Sync","Encrypted backup options",()->showSettings());
        LinearLayout cloud=col();cloud.setGravity(Gravity.CENTER);cloud.setBackground(solid(PANEL,19,BORDER));padding(cloud,17,18,17,18);
        ImageView c=new ImageView(this);int cloudId=getResources().getIdentifier("onboard_cloud","drawable",getPackageName());if(cloudId!=0)c.setImageResource(cloudId);
        c.setScaleType(ImageView.ScaleType.CENTER_CROP);c.setBackground(solid(0xFF0B0A18,18,BORDER));c.setClipToOutline(true);
        cloud.addView(c,new LinearLayout.LayoutParams(-1,dp(170)));
        TextView t=txt("Cloud Backup (Optional)",15,WHITE,true);t.setGravity(Gravity.CENTER);cloud.addView(t);
        TextView d=txt("Cloud sync is not connected in this build. Export an encrypted backup and move it between your devices manually.",10,SOFT,false);d.setGravity(Gravity.CENTER);cloud.addView(d);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(15);page.addView(cloud,cp);
        button("EXPORT ENCRYPTED BACKUP",()->{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"SPY_VAULT_Encrypted_Backup.spyvault");startActivityForResult(i,REQ_EXPORT);
        });
        ghostButton("RESTORE ENCRYPTED BACKUP",()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,REQ_IMPORT);
        });
        button("SET UP E2E CLOUD RECOVERY",()->showCloudRecovery());
        card("END-TO-END ENCRYPTION","Only the AES-256-GCM encrypted vault container is sent. The server never receives your master password or decrypted records.","ON",null);
        card("CLOUD ACCESS","Supabase Auth + per-user Row Level Security protect each account's encrypted backup.","RLS",null);
        card("RECOVERY NOTE","You must remember your master password. Without it, the encrypted cloud copy cannot be decrypted.","IMPORTANT",null);
    }

    private void showCloudRecovery(){
        initInner("E2E Cloud Recovery","One-time account link · automatic encrypted sync",()->showBackup());
        card("PRIVATE BY DESIGN","Your vault is encrypted on this device before upload. Cloud storage receives ciphertext only. Use a separate cloud-account password; it is not your vault master password.","E2E",null);
        fieldLabel("CLOUD ACCOUNT EMAIL"); EditText email=new EditText(this);email.setSingleLine(true);email.setHint("you@example.com");email.setTextColor(WHITE);email.setHintTextColor(MUTED);email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);email.setBackground(solid(PANEL2,14,BORDER));padding(email,14,12,14,12);page.addView(email,new LinearLayout.LayoutParams(-1,dp(54)));
        gap(page,10);fieldLabel("CLOUD ACCOUNT PASSWORD"); EditText pw=secretEdit("Create or enter cloud account password");
        button("CREATE CLOUD ACCOUNT & LINK",()->{String e=email.getText().toString().trim(),p=pw.getText().toString();if(!validCloudInput(e,p))return;cloudSignup(e,p);});
        button("LINK ACCOUNT & ENABLE AUTO SYNC",()->{String e=email.getText().toString().trim(),p=pw.getText().toString();if(!validCloudInput(e,p))return;if(!hasVault()||!isUnlocked){toast("Unlock your local vault first to upload it.");return;}cloudLoginAndUpload(e,p);});
        ghostButton("SIGN IN & RESTORE CLOUD VAULT",()->{String e=email.getText().toString().trim(),p=pw.getText().toString();if(!validCloudInput(e,p))return;cloudLoginAndRestore(e,p);});
        card("HOW RECOVERY WORKS","After reinstall, choose Restore, sign in with your cloud account, then enter the original vault master password. Your encrypted vault is downloaded and decrypted locally.","RESTORE",null);
        card("LIMITS","Link your cloud account once. After that, every saved vault change is encrypted and queued for automatic upload; each unlock checks for newer cloud data. You do not need to press Sync again. Keep your master password safe.","PHASE 1",null);
    }
    private boolean validCloudInput(String email,String pass){
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()){toast("Enter a valid email address.");return false;}
        if(pass.length()<8){toast("Cloud account password must be at least 8 characters.");return false;}return true;
    }
    private void cloudSignup(String email,String password){
        cloudWorker(()->{try{JSONObject b=new JSONObject();b.put("email",email);b.put("password",password);JSONObject r=cloudRequest("/auth/v1/signup","POST",null,b);if(!r.optString("access_token","").isEmpty()){
                rememberCloudSession(r);
                handler.post(()->{toast("Cloud account linked. Automatic sync enabled.");startAutomaticCloudSync();showBackup();});
            }else{
                handler.post(()->new AlertDialog.Builder(this).setTitle("Cloud account created").setMessage("Verify your email, then sign in once. Automatic encrypted sync will start after linking.").setPositiveButton("OK",null).show());
            }}catch(Exception ex){cloudError(ex);}});
    }
    private void cloudLoginAndUpload(String email,String password){
        cloudWorker(()->{try{JSONObject auth=cloudLogin(email,password);rememberCloudSession(auth);String token=auth.optString("access_token","");JSONObject user=auth.optJSONObject("user");if(token.isEmpty()||user==null)throw new IOException("Email confirmation may be required. Verify your email and sign in again.");String uid=user.optString("id","");if(uid.isEmpty())throw new IOException("Cloud account ID missing.");byte[] raw=readLocalVaultFile();String encoded=android.util.Base64.encodeToString(raw,android.util.Base64.NO_WRAP);JSONObject body=new JSONObject();body.put("user_id",uid);body.put("ciphertext",encoded);body.put("format_version",1);body.put("revision",System.currentTimeMillis());body.put("device_label",android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL);cloudRequest("/rest/v1/vault_sync?on_conflict=user_id","POST",token,body,true);
            getSharedPreferences(CLOUD_PREF,MODE_PRIVATE).edit().putLong("last_revision",body.optLong("revision",0)).putBoolean("dirty",false).apply();
            handler.post(()->{toast("Encrypted vault synced to cloud.");showCloudRecovery();});}catch(Exception ex){cloudError(ex);}});
    }
    private void cloudLoginAndRestore(String email,String password){
        cloudWorker(()->{try{JSONObject auth=cloudLogin(email,password);rememberCloudSession(auth);String token=auth.optString("access_token","");if(token.isEmpty())throw new IOException("Sign-in did not return a session. Verify your email if required.");JSONObject[] rows=cloudGetVault(token);if(rows.length==0)throw new IOException("No cloud backup found for this account.");String encoded=rows[0].optString("ciphertext","");byte[] raw=android.util.Base64.decode(encoded,android.util.Base64.DEFAULT);if(raw.length<40)throw new IOException("Cloud backup is incomplete.");handler.post(()->promptCloudRestore(raw));}catch(Exception ex){cloudError(ex);}});
    }
    private void promptCloudRestore(byte[] raw){
        LinearLayout box=col();padding(box,8,4,8,4);EditText master=new EditText(this);master.setSingleLine(true);master.setTextColor(WHITE);master.setHintTextColor(MUTED);master.setHint("Enter original vault master password");master.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);master.setBackground(solid(PANEL2,14,BORDER));padding(master,14,12,14,12);box.addView(master,new LinearLayout.LayoutParams(-1,dp(54)));
        new AlertDialog.Builder(this).setTitle("Decrypt cloud vault").setMessage("The backup stays encrypted until your master password successfully decrypts it on this phone.").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("RESTORE",(d,w)->{try{VaultData data=readVaultFromBytes(master.getText().toString().toCharArray(),raw);writeLocalVaultFile(raw);activeKey=data.key;records=data.records;isUnlocked=true;showHome();toast("Cloud vault restored successfully.");startAutomaticCloudSync();}catch(Exception ex){toast("Master password incorrect or cloud backup damaged.");}}).show();
    }
    private VaultData readVaultFromBytes(char[] password,byte[] raw)throws Exception{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));int ver=in.readInt();if(ver!=1)throw new IOException("Vault version");int sl=in.readInt();if(sl!=SALT_LEN)throw new IOException("Salt length");byte[] salt=new byte[sl];in.readFully(salt);int nl=in.readInt();if(nl!=NONCE_LEN)throw new IOException("Nonce length");byte[] nonce=new byte[nl];in.readFully(nonce);int cl=in.readInt();if(cl<16||cl>10000000)throw new IOException("Ciphertext length");byte[] ct=new byte[cl];in.readFully(ct);if(in.read()!=-1)throw new IOException("Trailing data");byte[] key=derive(password,salt);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));c.updateAAD("SPYVAULT-LOCAL-v1".getBytes("UTF-8"));return new VaultData(key,new JSONArray(new String(c.doFinal(ct),"UTF-8")));
    }
    private byte[] readLocalVaultFile()throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream in=openFileInput(FILE)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)b.write(buf,0,n);}return b.toByteArray();}
    private void writeLocalVaultFile(byte[] raw)throws Exception{File tmp=new File(getFilesDir(),FILE+".restore");try(FileOutputStream o=new FileOutputStream(tmp)){o.write(raw);o.getFD().sync();}File dst=getFileStreamPath(FILE);if(dst.exists()&&!dst.delete())throw new IOException("Could not replace local vault");if(!tmp.renameTo(dst))throw new IOException("Could not commit restored vault");}

    // Cloud session: refresh token is encrypted with an Android Keystore AES key.
    private static final String CLOUD_PREF="spyvault_cloud";
    private static final String CLOUD_ALIAS="SPY_VAULT_CLOUD_SESSION_V1";
    private javax.crypto.SecretKey cloudSessionKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(CLOUD_ALIAS))return (javax.crypto.SecretKey)ks.getKey(CLOUD_ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(CLOUD_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }
    private void rememberCloudSession(JSONObject auth) throws Exception {
        String refresh=auth.optString("refresh_token","");
        String access=auth.optString("access_token","");
        if(refresh.isEmpty())return;
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,cloudSessionKey());
        byte[] encrypted=c.doFinal(refresh.getBytes("UTF-8"));
        String packed=android.util.Base64.encodeToString(c.getIV(),android.util.Base64.NO_WRAP)+"."+android.util.Base64.encodeToString(encrypted,android.util.Base64.NO_WRAP);
        getSharedPreferences(CLOUD_PREF,MODE_PRIVATE).edit().putString("refresh",packed)
            .putString("email",auth.optJSONObject("user")==null?"":auth.optJSONObject("user").optString("email",""))
            .putString("access",access).apply();
    }
    private String rememberedRefreshToken() throws Exception {
        String packed=getSharedPreferences(CLOUD_PREF,MODE_PRIVATE).getString("refresh","");
        if(packed.isEmpty())return "";
        String[] parts=packed.split("\\\\.",2);if(parts.length!=2)throw new IOException("Saved cloud session is damaged");
        byte[] iv=android.util.Base64.decode(parts[0],android.util.Base64.DEFAULT);
        byte[] ct=android.util.Base64.decode(parts[1],android.util.Base64.DEFAULT);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,cloudSessionKey(),new GCMParameterSpec(128,iv));
        return new String(c.doFinal(ct),"UTF-8");
    }
    private void startAutomaticCloudSync(){
        if(!isUnlocked || activeKey==null || !cloudSyncRunning.compareAndSet(false,true))return;
        cloudWorker(()->{
            try{
                String refresh=rememberedRefreshToken();if(refresh.isEmpty())return;
                JSONObject rb=new JSONObject();rb.put("refresh_token",refresh);
                JSONObject session=cloudRequest("/auth/v1/token?grant_type=refresh_token","POST",null,rb);
                rememberCloudSession(session);
                String token=session.optString("access_token","");if(token.isEmpty())throw new IOException("Cloud session expired. Sign in again.");
                android.content.SharedPreferences prefs=getSharedPreferences(CLOUD_PREF,MODE_PRIVATE);
                boolean dirty=prefs.getBoolean("dirty",false);
                long last=prefs.getLong("last_revision",0);
                JSONObject[] rows=cloudGetVault(token);
                long remoteRevision=rows.length>0?rows[0].optLong("revision",0):0;
                if(dirty && remoteRevision>last){
                    handler.post(()->toast("Cloud has newer changes from another device. Sync paused to prevent overwriting them; review Backup & Sync."));
                    return;
                }
                if(!dirty && rows.length>0 && remoteRevision>last){
                    String encoded=rows[0].optString("ciphertext","");
                    byte[] raw=android.util.Base64.decode(encoded,android.util.Base64.DEFAULT);
                    VaultData incoming=readVaultFromBytesWithKey(raw,activeKey);
                    if(!isUnlocked)return;
                    writeLocalVaultFile(raw);records=incoming.records;
                    long rev=rows[0].optLong("revision",0);
                    prefs.edit().putLong("last_revision",rev).putBoolean("dirty",false).apply();
                    handler.post(()->{if(isUnlocked){showHome();toast("Latest cloud vault synced.");}});
                    return;
                }
                if(dirty || rows.length==0){
                    byte[] raw=readLocalVaultFile();
                    long revision=Math.max(System.currentTimeMillis(),last+1);
                    JSONObject body=new JSONObject();String uid=session.optJSONObject("user")==null?"":session.optJSONObject("user").optString("id","");
                    if(uid.isEmpty() && rows.length>0) uid=rows[0].optString("user_id","");
                    if(uid.isEmpty())throw new IOException("Cloud account identity missing. Sign in again.");
                    body.put("user_id",uid);body.put("ciphertext",android.util.Base64.encodeToString(raw,android.util.Base64.NO_WRAP));
                    body.put("format_version",1);body.put("revision",revision);body.put("device_label",Build.MANUFACTURER+" "+Build.MODEL);
                    cloudRequest("/rest/v1/vault_sync?on_conflict=user_id","POST",token,body,true);
                    prefs.edit().putLong("last_revision",revision).putBoolean("dirty",false).apply();
                    handler.post(()->toast("Automatic encrypted cloud sync complete."));
                }
            }catch(Exception ex){cloudError(ex);}
            finally{cloudSyncRunning.set(false);}
        });
    }
    private VaultData readVaultFromBytesWithKey(byte[] raw,byte[] key)throws Exception{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));int ver=in.readInt();if(ver!=1)throw new IOException("Vault version");
        int sl=in.readInt();if(sl!=SALT_LEN)throw new IOException("Salt length");byte[] salt=new byte[sl];in.readFully(salt);
        int nl=in.readInt();if(nl!=NONCE_LEN)throw new IOException("Nonce length");byte[] nonce=new byte[nl];in.readFully(nonce);
        int cl=in.readInt();if(cl<16||cl>10000000)throw new IOException("Ciphertext length");byte[] ct=new byte[cl];in.readFully(ct);
        if(in.read()!=-1)throw new IOException("Trailing data");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
        c.updateAAD("SPYVAULT-LOCAL-v1".getBytes("UTF-8"));
        return new VaultData(key,new JSONArray(new String(c.doFinal(ct),"UTF-8")));
    }
    private JSONObject cloudLogin(String email,String password)throws Exception{JSONObject b=new JSONObject();b.put("email",email);b.put("password",password);return cloudRequest("/auth/v1/token?grant_type=password","POST",null,b);}
    private JSONObject[] cloudGetVault(String token)throws Exception{JSONArray a=cloudRequestArray("/rest/v1/vault_sync?select=ciphertext,revision&limit=1","GET",token,null);JSONObject[] out=new JSONObject[a.length()];for(int i=0;i<a.length();i++)out[i]=a.getJSONObject(i);return out;}
    private interface CloudTask{void run();}
    private void cloudWorker(CloudTask task){Toast.makeText(this,"Connecting securely…",Toast.LENGTH_SHORT).show();new Thread(()->task.run()).start();}
    private void cloudError(Exception ex){String m=ex.getMessage()==null?"Cloud request failed.":ex.getMessage();handler.post(()->toast("Cloud: "+m));}
    private JSONObject cloudRequest(String path,String method,String token,JSONObject body)throws Exception{return cloudRequest(path,method,token,body,false);}
    private JSONObject cloudRequest(String path,String method,String token,JSONObject body,boolean preferMerge)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(CLOUD_URL+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("apikey",CLOUD_ANON);c.setRequestProperty("Accept","application/json");if(token!=null)c.setRequestProperty("Authorization","Bearer "+token);if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");if(preferMerge)c.setRequestProperty("Prefer","resolution=merge-duplicates,return=minimal");byte[] data=body.toString().getBytes("UTF-8");try(OutputStream o=c.getOutputStream()){o.write(data);}}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String response=readText(in);c.disconnect();if(code<200||code>=300)throw new IOException("HTTP "+code+": "+response);return response.trim().isEmpty()?new JSONObject():new JSONObject(response);}
    private JSONArray cloudRequestArray(String path,String method,String token,JSONObject body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(CLOUD_URL+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("apikey",CLOUD_ANON);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String response=readText(in);c.disconnect();if(code<200||code>=300)throw new IOException("HTTP "+code+": "+response);return new JSONArray(response);}
    private String readText(InputStream in)throws Exception{if(in==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);return b.toString();}}

    private void showAppearance(){
        initInner("Appearance","Personalize your vault",()->showSettings());
        appearanceSegment("THEME",new String[]{"Dark","Light","System"},themeMode,mode->setThemeMode(mode));
        TextView accentTitle=txt("ACCENT COLOR",10,SOFT,true);accentTitle.setLetterSpacing(.12f);
        LinearLayout.LayoutParams atp=new LinearLayout.LayoutParams(-1,-2);atp.topMargin=dp(16);atp.bottomMargin=dp(9);page.addView(accentTitle,atp);
        LinearLayout swatches=row();swatches.setGravity(Gravity.CENTER);
        String[] names={"Purple","Blue","Orange","Cyan","Red"};
        int[] colors={0xFFA855F7,0xFF3994FF,0xFFFF9A35,0xFF22D3EE,0xFFF05272};
        for(int i=0;i<names.length;i++){
            final String name=names[i];LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER);
            TextView dot=txt(accentMode.equals(name)?"✓":"",14,Color.WHITE,true);dot.setGravity(Gravity.CENTER);
            dot.setBackground(solid(colors[i],30,accentMode.equals(name)?Color.WHITE:0));
            LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(dp(35),dp(35));dp.leftMargin=dp(8);dp.rightMargin=dp(8);wrap.addView(dot,dp);
            TextView label=txt(name,8,accentMode.equals(name)?WHITE:MUTED,true);label.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(5);wrap.addView(label,lp);
            swatches.addView(wrap,new LinearLayout.LayoutParams(0,-2,1));
            wrap.setOnClickListener(v->setAccentMode(name));
        }
        page.addView(swatches);
        appearanceSegment("FONT SIZE",new String[]{"Small","Medium","Large"},fontMode,mode->setFontMode(mode));
        card("PREVIEW","Your vault uses rounded surfaces, high-contrast text and the selected accent color.","LIVE",null);
        ghostButton("BACK TO SETTINGS",()->showSettings());
    }
    private interface ChoiceAction{void choose(String value);}
    private void appearanceSegment(String label,String[] values,String selected,ChoiceAction action){
        TextView title=txt(label,10,SOFT,true);title.setLetterSpacing(.12f);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.bottomMargin=dp(8);page.addView(title,tp);
        LinearLayout choices=row();choices.setBackground(solid(PANEL,15,BORDER));padding(choices,5,5,5,5);
        for(String value:values){
            TextView c=txt(value,10,value.equals(selected)?Color.WHITE:SOFT,true);c.setGravity(Gravity.CENTER);
            if(value.equals(selected))c.setBackground(gradient(11));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(40),1);cp.rightMargin=dp(3);choices.addView(c,cp);
            c.setOnClickListener(v->action.choose(value));
        }
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(15);page.addView(choices,p);
    }

    private void showAbout() {
        initInner("About SPY VAULT","Your private password vault",()->showSettings());
        ImageView logo=new ImageView(this);int id=getResources().getIdentifier("spy_vault_mark","drawable",getPackageName());if(id!=0)logo.setImageResource(id);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(190),dp(190));lp.gravity=Gravity.CENTER;page.addView(logo,lp);
        TextView ver=txt("SPY VAULT  v0.8.2",9,PURPLE,true);ver.setGravity(Gravity.CENTER);page.addView(ver);
        card("ABOUT","A local-first password manager with encrypted storage.","",null);
        settingsRow("Privacy Policy","How SPY VAULT handles your data","◈",()->showLegal("Privacy Policy","Your vault contents are encrypted and stored in app-private local storage. This build does not upload passwords or account details to a cloud service. Keep your master password private."));
        settingsRow("Terms of Service","Development build terms","▤",()->showLegal("Terms of Service","SPY VAULT is provided as a development build. Keep separate encrypted backups and verify restore access. No independent security certification is claimed."));
        settingsRow("Open Source Licenses","Third-party notices","ⓘ",()->showLegal("Open Source Licenses","This build uses Android platform APIs and standard Java/Android libraries. No additional third-party UI framework is bundled."));
        settingsRow("Check for Updates","Current version 0.8.2","↻",()->toast("You are using the current development build."));
        card("SECURITY","AES-256-GCM authenticated encryption with PBKDF2-HMAC-SHA256 key derivation.","LOCAL",null);
        card("IMPORTANT","No independent penetration test or security certification has been completed. Keep a separate secure backup of critical credentials.","NOTICE",null);
    }

    private void showLegal(String title,String message){
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("CLOSE",null).show();
    }

    // Biometric support: Android system prompt and device-bound Android Keystore key.
    private boolean hasVault(){return getFileStreamPath(FILE).exists();}
    private boolean hasBiometricKey(){return Build.VERSION.SDK_INT>=28&&getFileStreamPath(BIO_FILE).exists();}
    private String biometricReadiness(){
        if(Build.VERSION.SDK_INT<28)return "Fingerprint unlock needs Android 9 or newer.";
        if(Build.VERSION.SDK_INT>=29){
            android.hardware.biometrics.BiometricManager bm=(android.hardware.biometrics.BiometricManager)getSystemService(BIOMETRIC_SERVICE);
            if(bm!=null){
                int r=Build.VERSION.SDK_INT>=30
                    ? bm.canAuthenticate(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    : bm.canAuthenticate();
                if(r==android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE)return "No compatible biometric sensor reported by this device.";
                if(r==android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE)return "Biometric sensor temporarily unavailable.";
                if(r==android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED)return "Enroll a fingerprint in Android Settings first.";
            }
        }return null;
    }
    private SecretKey biometricKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(BIO_ALIAS))return (SecretKey)ks.getKey(BIO_ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        KeyGenParameterSpec.Builder b=new KeyGenParameterSpec.Builder(BIO_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).setUserAuthenticationRequired(true).setInvalidatedByBiometricEnrollment(true);
        if(Build.VERSION.SDK_INT>=30)b.setUserAuthenticationParameters(0,KeyProperties.AUTH_BIOMETRIC_STRONG);
        else b.setUserAuthenticationValidityDurationSeconds(-1);
        kg.init(b.build());return kg.generateKey();
    }
    private void enableBiometric(){
        if(Build.VERSION.SDK_INT<28){toast("Biometric prompt needs Android 9+.");return;}
        if(!isUnlocked||activeKey==null){toast("Unlock vault first.");return;}
        String r=biometricReadiness();if(r!=null){toast(r);return;}
        try{
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(BIO_ALIAS))ks.deleteEntry(BIO_ALIAS);deleteFile(BIO_FILE);
            SecretKey key=biometricKey();Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);
            BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Enable SPY VAULT fingerprint")
                .setSubtitle("Protect your vault key on this device").setNegativeButton("CANCEL",getMainExecutor(),(d,w)->{}).build();
            prompt.authenticate(new BiometricPrompt.CryptoObject(cipher),new CancellationSignal(),getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
                    try{Cipher c=result.getCryptoObject().getCipher();byte[] wrapped=c.doFinal(activeKey),iv=c.getIV();
                        DataOutputStream out=new DataOutputStream(openFileOutput(BIO_FILE,MODE_PRIVATE));out.writeInt(1);out.writeInt(iv.length);out.write(iv);out.writeInt(wrapped.length);out.write(wrapped);out.close();
                        toast("Fingerprint unlock enabled.");showSecurity();
                    }catch(Exception e){toast("Fingerprint setup failed.");}
                }
                @Override public void onAuthenticationError(int code,CharSequence msg){toast("Fingerprint setup: "+msg);}
            });
        }catch(Exception e){toast("Biometric setup unavailable: "+e.getClass().getSimpleName());}
    }
    private void beginBiometricUnlock(){
        String r=biometricReadiness();if(r!=null){toast(r);return;}
        try{
            DataInputStream in=new DataInputStream(openFileInput(BIO_FILE));int ver=in.readInt(),il=in.readInt();
            if(ver!=1||il<12||il>32)throw new IOException("Invalid key envelope");
            byte[] iv=new byte[il];in.readFully(iv);int cl=in.readInt();if(cl<16||cl>1024)throw new IOException("Invalid key envelope");
            byte[] wrapped=new byte[cl];in.readFully(wrapped);in.close();
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);SecretKey key=(SecretKey)ks.getKey(BIO_ALIAS,null);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));
            BiometricPrompt p=new BiometricPrompt.Builder(this).setTitle("Unlock SPY VAULT").setSubtitle("Confirm your fingerprint")
                .setNegativeButton("USE MASTER PASSWORD",getMainExecutor(),(d,w)->{}).build();
            p.authenticate(new BiometricPrompt.CryptoObject(cipher),new CancellationSignal(),getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
                    try{activeKey=result.getCryptoObject().getCipher().doFinal(wrapped);records=readVaultWithKey(activeKey);isUnlocked=true;showHome();}
                    catch(Exception e){lockVault();toast("Fingerprint unlock failed. Use master password.");}
                }
                @Override public void onAuthenticationError(int code,CharSequence msg){toast("Biometric unlock: "+msg);}
            });
        }catch(Exception e){toast("Biometric unlock unavailable. Use master password.");}
    }
    private JSONArray readVaultWithKey(byte[] key)throws Exception{
        VaultBytes v=readEncryptedBytes();
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,v.nonce));
        c.updateAAD("SPYVAULT-LOCAL-v1".getBytes("UTF-8"));return new JSONArray(new String(c.doFinal(v.ciphertext),"UTF-8"));
    }
    private void deleteBiometricMaterial(){
        try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(BIO_ALIAS))ks.deleteEntry(BIO_ALIAS);}catch(Exception ignored){}
        deleteFile(BIO_FILE);
    }

    // Existing vault format is deliberately preserved for app-update compatibility.
    private static class VaultData{byte[] key;JSONArray records;VaultData(byte[] k,JSONArray r){key=k;records=r;}}
    private static class VaultBytes{byte[] salt,nonce,ciphertext;VaultBytes(byte[]s,byte[]n,byte[]c){salt=s;nonce=n;ciphertext=c;}}
    private VaultBytes readEncryptedBytes()throws Exception{
        DataInputStream in=new DataInputStream(openFileInput(FILE));int ver=in.readInt();if(ver!=1)throw new IOException("Vault version");
        int sl=in.readInt();if(sl!=SALT_LEN)throw new IOException("Salt length");byte[] salt=new byte[sl];in.readFully(salt);
        int nl=in.readInt();if(nl!=NONCE_LEN)throw new IOException("Nonce length");byte[] nonce=new byte[nl];in.readFully(nonce);
        int cl=in.readInt();if(cl<16||cl>10_000_000)throw new IOException("Ciphertext length");byte[] ct=new byte[cl];in.readFully(ct);
        if(in.read()!=-1)throw new IOException("Unexpected trailing data");in.close();return new VaultBytes(salt,nonce,ct);
    }
    private byte[] derive(char[] password,byte[] salt)throws Exception{
        PBEKeySpec spec=new PBEKeySpec(password,salt,ITERATIONS,KEY_BITS);
        try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}
        finally{spec.clearPassword();}
    }
    private VaultData readVault(char[] password)throws Exception{
        VaultBytes v=readEncryptedBytes();byte[] key=derive(password,v.salt);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,v.nonce));
        c.updateAAD("SPYVAULT-LOCAL-v1".getBytes("UTF-8"));String json=new String(c.doFinal(v.ciphertext),"UTF-8");
        return new VaultData(key,new JSONArray(json));
    }
    private void saveVault(byte[] salt,byte[] key,JSONArray data)throws Exception{
        byte[] nonce=randomBytes(NONCE_LEN);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));c.updateAAD("SPYVAULT-LOCAL-v1".getBytes("UTF-8"));
        byte[] ct=c.doFinal(data.toString().getBytes("UTF-8"));
        File tmp=new File(getFilesDir(),FILE+".tmp");
        try(FileOutputStream fos=new FileOutputStream(tmp);DataOutputStream out=new DataOutputStream(fos)){
            out.writeInt(1);out.writeInt(salt.length);out.write(salt);out.writeInt(nonce.length);out.write(nonce);out.writeInt(ct.length);out.write(ct);out.flush();fos.getFD().sync();
        }
        File dst=getFileStreamPath(FILE);if(dst.exists()&&!dst.delete())throw new IOException("Could not replace vault");
        if(!tmp.renameTo(dst))throw new IOException("Could not commit encrypted vault");
    }
    private void persist(){
        try{
            VaultBytes v=readEncryptedBytes();saveVault(v.salt,activeKey,records);
            android.content.SharedPreferences cp=getSharedPreferences(CLOUD_PREF,MODE_PRIVATE);
            if(!cp.getString("refresh","").isEmpty()){
                cp.edit().putBoolean("dirty",true).apply();
                handler.removeCallbacks(autoSyncRunnable);handler.postDelayed(autoSyncRunnable,1800);
            }
        }catch(Exception e){toast("Encrypted save failed.");}
    }
    private final Runnable autoSyncRunnable=()->startAutomaticCloudSync();
    private void lockVault(){
        if(activeKey!=null)java.util.Arrays.fill(activeKey,(byte)0);
        activeKey=null;records=new JSONArray();isUnlocked=false;recordsHost=null;
    }

    private String generatePassword(int n){return generatePassword(n,"ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*_-+");}
    private String generatePassword(int n,String chars){
        StringBuilder b=new StringBuilder(n);int bound=256-(256%chars.length());
        while(b.length()<n){byte[] data=randomBytes(Math.max(16,n-b.length()));for(byte by:data){int x=by&255;if(x<bound){b.append(chars.charAt(x%chars.length()));if(b.length()==n)break;}}}return b.toString();
    }
    private byte[] randomBytes(int n){byte[] b=new byte[n];random.nextBytes(b);return b;}
    private void copy(String value){
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("SPY VAULT",value));
        toast("Copied. Clipboard clears in 30 seconds (best-effort).");
        handler.postDelayed(()->{try{
            if(cm.getPrimaryClip()!=null&&value.contentEquals(cm.getPrimaryClip().getItemAt(0).coerceToText(this)))cm.setPrimaryClip(ClipData.newPlainText("",""));
        }catch(Exception ignored){}},30000);
    }
    private void hideKeyboard(){
        try{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(page.getWindowToken(),0);}catch(Exception ignored){}
    }
    private void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();}

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            if(req==REQ_EXPORT){
                try(InputStream in=openFileInput(FILE);OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new IOException("No destination");byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
                }toast("Encrypted backup exported.");
            }else if(req==REQ_IMPORT){
                byte[] b;
                try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    if(in==null)throw new IOException("No input");byte[] buf=new byte[8192];int n,total=0;
                    while((n=in.read(buf))>0){total+=n;if(total>10_000_000)throw new IOException("Backup too large");out.write(buf,0,n);}b=out.toByteArray();
                }
                // Only basic container validation here. GCM authentication is checked on next master-password unlock.
                try(DataInputStream check=new DataInputStream(new ByteArrayInputStream(b))){
                    int v=check.readInt(),sl=check.readInt();if(v!=1||sl!=SALT_LEN)throw new IOException("Invalid backup");
                    byte[] salt=new byte[sl];check.readFully(salt);int nl=check.readInt();if(nl!=NONCE_LEN)throw new IOException("Invalid backup");
                    byte[] nonce=new byte[nl];check.readFully(nonce);int cl=check.readInt();if(cl<16||cl>10_000_000)throw new IOException("Invalid backup");
                    byte[] ct=new byte[cl];check.readFully(ct);if(check.available()!=0)throw new IOException("Unexpected trailing data");
                }
                File temp=new File(getCacheDir(),"vault_restore.tmp");
                try(FileOutputStream f=new FileOutputStream(temp)){f.write(b);f.getFD().sync();}
                new AlertDialog.Builder(this).setTitle("Restore encrypted backup?")
                    .setMessage("This replaces the current vault. Continue only if you have separately backed up the current file.")
                    .setNegativeButton("CANCEL",(d,w)->temp.delete())
                    .setPositiveButton("RESTORE",(d,w)->{
                        try(FileInputStream in=new FileInputStream(temp);FileOutputStream out=openFileOutput(FILE,MODE_PRIVATE)){
                            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.getFD().sync();temp.delete();
                            lockVault();showGate();toast("Backup restored. Unlock with its master password.");
                        }catch(Exception e){toast("Restore failed.");}
                    }).show();
            }
        }catch(Exception e){toast("Backup failed: "+e.getMessage());}
    }
}
